

  <?php 
  require_once 'assets/vendor/mpdf/vendor/autoload.php';
$mpdf = new  \Mpdf\Mpdf(['UTF-8']);
ob_start();

          $staticdays  = array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
           foreach ($rsTable as $key => $value) {
            foreach ($staticdays as $key => $dayvalue) {
      
             if($value['days_name']== $dayvalue)
                {
                  for($k=1;$k<=7;$k++)
                  {
                    $contentValue ="";
                    if($value['slotsub'.$k.'']==$subjectid)
                    {
                     $contentValue .=$value['bname'].'('.$value['section'].')<br>';
                            foreach ($rsRoom as  $roomvalue) 
                            {
                              if($value['slotroom'.$k.'']==$roomvalue['RNO'])
                              {
                               $contentValue .=$roomvalue['rname'].'<br>';
                              }//end of if codition subject check
                            }//end of foreach loop subject
                            foreach ($rsTeacher as  $teavalue) 
                            {
                              if($value['slotteacher'.$k.'']==$teavalue['USER_ID'])
                              {
                                $contentValue .=$teavalue['user_name'];
                              }//end of if condition teacher check
                            }//end of foreach loop teacher
                       $finalTableData[$dayvalue][$k] = $contentValue;
                    }//end of if condition of room
                  }//end of for loop for seven days
                }//if condition when the date is match
              }//foreach loop for every days
            }//foreach loop for all row table
      ?>
      <link rel="stylesheet" href="<?= base_url("assets/vendor/bootstrap/css/bootstrap.min.css")?>">
      <style type="text/css">
        thead th
        {
          text-align: center;
        }
        tbody tr td
        {
          padding:10px;
        }
      </style>
      <div class="row table-rsponsive">
          <table class="table" border="1" >
          <thead>
            <tr>
                <th>#</th>
                <th style="padding-top: 10px;padding-bottom: 10px;" width="12%">D/T</th>
                <th width="12%">10 to 11</th>
                <th width="12%">11 to 12</th>
                <th width="12%">12 to 01</th>
                <th width="12%">01 to 02</th>
                <th width="12%">02 to 03</th>
                <th width="12%">03 to 04</th>
                <th width="12%">04 to 05</th>
            </tr>
          </thead>
        <tbody>
         <?php
        $i=0;
         foreach ($staticdays as $key => $dayvalue) {
           echo "<tr>
                <td align='center'>".++$i."</td>
                <td>".$dayvalue."</td>";
                  for ($k=1; $k <=7 ; $k++)
                  { 
                    if(!empty($finalTableData))
                    {
                      if(array_key_exists($dayvalue,$finalTableData))  
                      {
                        if(!empty($finalTableData[$dayvalue][$k]))
                        {
                          echo "<td>".$finalTableData[$dayvalue][$k]."</td>";
                        }
                        else
                        {
                          echo "<td></td>";
                        }
                      }
                      else
                      {
                        echo "<td></td>";
                      }
                    }
                    else
                    {
                        echo "<td></td>";
                    }
                  }
                echo"
              </tr>";
         }
     
         ?>
       </tbody>
      </table>
    </div>
    <table>
        <tr><td>First row between Days&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</td><td>&nbsp;&nbsp;Branch/Semester</td></tr>
        <tr><td>Second row between Days&nbsp;:</td><td>&nbsp;&nbsp;Room Name</td></tr>
        <tr><td>Thired row between Days&nbsp;&nbsp;&nbsp;:</td><td>&nbsp;&nbsp;Teacher Name</td></tr>
      </table>
    <?php
  $html = ob_get_contents();
  ob_end_clean();
  $mpdf->AddPage('L'); 
  $mpdf->WriteHTML($html);
  $mpdf->SetTitle("Time Table" );
  $mpdf->Output();
?>




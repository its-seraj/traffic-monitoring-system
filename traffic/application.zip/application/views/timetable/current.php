<div class="col-sm-12">
	<div class="card">  
    <div class="card-header">
      <h3 class="card-title"><?= $title; ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
       <?php 
        //id or password incorrect
        if($this->session->flashdata('statusType'))
        {
            echo '<div class="alert alert-'.$this->session->statusType.' alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <p>'.$this->session->statusMsg.'</p>
                  </div>';
        }
      ?>
 
	 <div class="row">
	 	<div class="col-sm-4">
	 	<form action="<?= site_url('timetable/search')?>" method ="post">
		 <fieldset>
		  <legend>Search:</legend>
		  <div class="row">
		  	<div class="col-sm-6">
				<div class="form-group">
				  	<label>Techer Name:</label>
					  	<select name="teacher" class="form-control" onchange="teacherChange(this)">
					  		<option value="">Select Any One</option>
					  		<?php
						  		foreach ($rsTeacher as $key => $value) {
						  			echo "<option value='".$value['USER_ID']."'>".$value['user_name']."</option>";
						  		}
					  		?>	
					  	</select>
				</div>
			</div>
			<div class="col-sm-1">
				<div class="form-group">
					<br>
					<label>or</label>
				</div>
			</div>
			<div class="col-sm-5">
				<div class="form-group">
				  	<label>Room Name:</label>
					  	<select name="room" class="form-control" onchange="roomChange(this)">
					  		<option value="">Select Any One</option>
					  		<?php
						  		foreach ($rsRoom as $key => $value) {
						  			echo "<option value='".$value['RNO']."'>".$value['rname']."</option>";
						  		}
					  		?>	
					  	</select>
				</div>
			</div>
		  </div>
		  <div class="form-group">
		  	<label>Period:</label>
			  	<select name="period" class="form-control">
			  		<option value="">Select Any One</option>
			  		<option value="1">10 to 11</option>
			  		<option value="2">11 to 12</option>
			  		<option value="3">12 to 01</option>
			  		<option value="4">01 to 02</option>
			  		<option value="5">02 to 03</option>
			  		<option value="6">03 to 04</option>
			  		<option value="7">04 to 05</option>
			  	</select>
		  </div>
		  <div class="form-group">
		  	<label>Date</label>
		  	<input type="date" name="date" class="form-control" id ="datepicker">
		  </div>
		  <div class="form-group">
		  	<button type="button" class="btn btn-block btn-success" id="fittertimetable"><i class="fa fa-search" aria-hidden="true"></i>&nbsp;<b>Search</b></button>
		  </div>
		 </fieldset>
		</form>
	  </div><!-- end of col-sm-04 -->
	  <div class="col-sm-8 result">
	  </div>
	</div>
	 </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!--/.col-sm-12-->
<style>
  .error p{
    background-color: #5F5F5F;
    padding: 5px;
    color:white;
  }
</style>

<script type="text/javascript">
        $(function(){
          $('.sidebar-toggle').trigger('click');
          $('.active').removeClass("active");
          $('#pg-current').addClass("active");
        });
        

        $('#fittertimetable').click(function(){
			var teacher =	$('select[name="teacher"').val();
			var room 	=	$('select[name="room"').val();
			var period 	=	$('select[name="period"').val();
			var date 	=	$('input[name="date"').val();
			if(date=='')
			{
				alert("Date field can't empty");
			}
			else if(period=='')
			{
				alert("Please Select any one period");
			}
			else if(teacher =='' && room=='')
			{
				alert("please select Teacher or Room No.");
			}
			else
			{
			 var d = new Date(date);
			  var weekday = new Array(7);
			  weekday[0] = "Sunday";
			  weekday[1] = "Monday";
			  weekday[2] = "Tuesday";
			  weekday[3] = "Wednesday";
			  weekday[4] = "Thursday";
			  weekday[5] = "Friday";
			  weekday[6] = "Saturday";
			  var datename = weekday[d.getDay()];
			$.ajax({
				url:'<?= site_url("timetable/getsearchresult")?>',
				data:{teacher:teacher,room:room,period:period,date:datename},
				method:'post',
				success: function (res)
					{
						$('.result').html(res);
					}

				})
			}
        });
      function roomChange(a)
      {
      	if($(a).val()!='')
      	{
      		$('select[name="teacher"]').prop("disabled", true);

      	}
      	else
      	{
      		$('select[name="teacher"]').removeAttr("disabled");
      	}

      }
       function teacherChange(a)
      {
      	if($(a).val()!='')
      	{
      		$('select[name="room"]').prop("disabled", true);

      	}
      	else
      	{
      		$('select[name="room"]').removeAttr("disabled");
      	}

      }

    </script>


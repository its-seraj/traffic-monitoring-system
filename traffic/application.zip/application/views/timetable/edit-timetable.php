<div class="col-sm-12">
	<div class="card">  
    <div class="card-header">
      <h3 class="card-title"><?= $title; ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
       <?php 
        //id or password incorrect
        if($this->session->flashdata('statusType'))
        {
            echo '<div class="alert alert-'.$this->session->statusType.' alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <p>'.$this->session->statusMsg.'</p>
                  </div>';
        }
      ?>
  <form action="<?= base_url('timetable/edit_table')?>" method="post">

 	<div class="row">
    <?php 
//    print_r($rsTimetable);
    ?>
   	  <div class="col-sm-6">
        <div class="form-group">
          <label for="email">Brnach:</label>
          <input type="hidden" name="branchid" value="<?= $rsTimetable[0]['bid']?>">
          <input type="text" class="form-control" value="<?= $rsTimetable[0]['bname']?>" readonly>
        </div>
      </div>
       <div class="col-sm-6">
        <div class="form-group">
          <label for="email">Semester:</label>
          <input type="hidden" name="semsterNo" value="<?= $rsTimetable[0]['section']?>">
          <input type="text" class="form-control" value="<?= $rsTimetable[0]['section']?>" readonly>
        </div>
      </div>
    </div>
    	<div class="row table-rsponsive">
                <table class="table table-border table-striped ">
                <thead>
                    <tr>
                        <th>D/T</th>
                        <th>10 to 11<input type="checkbox" class="checkSelect" name="first" data-id="3"/></th>
                        <th>11 to 12<input type="checkbox" class="checkSelect" name="second" data-id="4"/></th>  
                        <th>12 to 01<input type="checkbox" class="checkSelect" name="thired" data-id="5"/></th>
                        <th>01 to 02<input type="checkbox" class="checkSelect" name="fourth" data-id="6"/></th>
                        <th>02 to 03<input type="checkbox" class="checkSelect" name="fivth" data-id="7"/></th>
                        <th>03 to 04<input type="checkbox" class="checkSelect" name="sixth" data-id="8"/></th>
                        <th>04 to 05<input type="checkbox" class="checkSelect" name="seven" data-id="9"/></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if(!empty($rsTimetable))
                    $i=0;
                    foreach ($rsTimetable as $value) {
                    echo '<tr>
                    <td>'.$value['days_name'].'<input type="hidden" name="days[]" value="'.$value['days_name'].'"></td>
                    ';
                    echo '<input type="hidden" name="mid[]" value="'.$value['MID'].'">';
                    $j=1;
                    for($k=0;$k<7;$k++)
                    {
                    echo'<td>
                        <select name="subject'.$i.'[]" class="form-control form-control-sm selectboxa subjectid" >
                        <option value="">Select Any One</option>';
                        foreach ($rsSubject as  $subvalue) {
                          if($value['slotsub'.$j.'']!=$subvalue['SUBID'])
                          {
                            echo '<option value="'.$subvalue['SUBID'].'">'.$subvalue['subcode'].'('.$subvalue['subname'].')</option>';
                          }
                          else
                          {
                            echo '<option value="'.$subvalue['SUBID'].'" selected>'.$subvalue['subcode'].'('.$subvalue['subname'].')</option>';
                          }
                        }
                    echo '</select>'; 
                    ?>

                        <select name="room<?= $i; ?>[]" class="form-control form-control-sm selectboxa roomid" onblur="getroom(this,'<?= $value['days_name']; ?>','<?= $k;?>')"><option value="">Select Any One</option>';
                       
                    <?php
                        foreach ($rsRoom as  $roomvalue) {
                          if($value['slotroom'.$j.'']!=$roomvalue['RNO'])
                          {
                            echo '<option value="'.$roomvalue['RNO'].'">'.$roomvalue['rname'].'</option>';
                          }
                          else
                          {
                            echo '<option value="'.$roomvalue['RNO'].'" selected>'.$roomvalue['rname'].'</option>';
                          }
                        }
                        echo'</select>'?>

                        <select name="teacher<?= $i; ?>[]" class="form-control form-control-sm selectboxa teacherid" onblur="getteacher(this,'<?= $value['days_name']; ?>','<?= $k;?>')"><option value="">Select Any One</option>';
                     
                        <?php
                         foreach ($rsTeacher as  $teachervalue) {
                          if($value['slotteacher'.$j.'']!=$teachervalue['USER_ID'])
                          {
                            echo '<option value="'.$teachervalue['USER_ID'].'">'.$teachervalue['user_name'].'</option>';
                          }
                          else
                          {
                            echo '<option value="'.$teachervalue['USER_ID'].'" selected>'.$teachervalue['user_name'].'</option>';
                          }
                        }
                        echo'</select>
                    </td>';
                     $j++;

                    }
                     $i++;
                    echo'</tr>';
                  } 
                  ?>
                </tbody>
              </table>
              <center>
                    <button class="btn btn-success btn-md">Submit</button>
                    <button class="btn btn-md">Reset</button>
              </center>
            </div>
          </form>
   <?php
  // echo "<pre>";
 //  print_r($rsTimetable);
   ?>
  </div>
  </form>
</div>

    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!--/.col-sm-12-->
<style>
  .error p{
    background-color: #5F5F5F;
    padding: 5px;
    color:white;
  }
</style>
<script type="text/javascript">
            $('.checkSelect').change(function(){
                if($(this).prop("checked")==true)
                 {
                     var id  = $(this).data('id');
                     var room  = $('table tbody tr:nth-child(1) td:nth-child('+id+') .roomid').children("option:selected").val();
                     var teacher  = $('table tbody tr:nth-child(1) td:nth-child('+id+') .teacherid').children("option:selected").val();
                     var subject  = $('table tbody tr:nth-child(1) td:nth-child('+id+') .subjectid').children("option:selected").val();
                     for(var i=2; i<=6; i++)
                     {
                        $('table tbody tr:nth-child('+i+') td:nth-child('+id+') .roomid').val(room);
                        $('table tbody tr:nth-child('+i+') td:nth-child('+id+') .teacherid').val(teacher);
                        $('table tbody tr:nth-child('+i+') td:nth-child('+id+') .subjectid').val(subject);
                     }
                 }
            });
             function getroom(a,daysname,columcount)
             {
              var branchid = $('input[name="branchid"]').val();
              var semsterNo = $('input[name="semsterNo"]').val();
                var id = $(a).val();
                if(id!='')
                    {
                    $.ajax({
                        url:'<?= site_url("room/checkroomableedit")?>',
                        data:{id:id,daysname:daysname,columcount:columcount,branchid:branchid,semsterNo:semsterNo},
                        method:'post',
                        dataType:'json',
                        success: function(json)
                        {   
                           if(json!='')
                           {
                            $('#myModal').modal();
                            $('#myModal .modal-title').html("Error");
                            $('#myModal .modal-body').html("This Room is already allocated for this time. <b>Please select another room</b>");
                            $('#myModal').on('hidden.bs.modal', function () {
                                    $(a).focus();
                                 });
                           }
                       }              
                    })
                }
             }
              function getteacher(a,daysname,columcount)
             {
              var branchid = $('input[name="branchid"]').val();
              var semsterNo = $('input[name="semsterNo"]').val();
                    var id = $(a).val();
                    if(id!='')
                    {
                        $.ajax({
                            url:'<?= site_url("teacher/checkteacherableedit")?>',
                            data:{id:id,daysname:daysname,columcount:columcount,branchid:branchid,semsterNo:semsterNo},
                            method:'post',
                            dataType:'json',
                            success: function(json)
                            {   
                               if(json!='')
                               {
                                $('#myModal').modal();
                                $('#myModal .modal-title').html("Error");
                                $('#myModal .modal-body').html("This <b>Teacher</b> is already allocated for this time. <b>Please select another Teacher Name<b>");
                                $('#myModal').on('hidden.bs.modal', function () {
                                        $(a).focus();
                                 });
                               }
                           }              
                        })
                    }
             }
</script>
<script type="text/javascript">
        $(function(){
          $('.sidebar-toggle').trigger('click');
          $('.active').removeClass("active");
          $('#pg-timetable').addClass("active");
        });
    </script>


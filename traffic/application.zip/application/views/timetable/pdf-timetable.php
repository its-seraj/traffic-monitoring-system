<?php 
require_once 'assets/vendor/mpdf/vendor/autoload.php';
$mpdf = new  \Mpdf\Mpdf(['UTF-8']);
ob_start();
?>
<link rel="stylesheet" href="<?= base_url("assets/vendor/bootstrap/css/bootstrap.min.css")?>">
 	<div class="row">
    <?php 
      if(!empty($rsTimetable)){?>
   	  <div class="col-xs-4">
        <div class="form-group">
          <label for="email">Branch:</label><?= $rsTimetable[0]['bname']?>
        </div>
      </div>
       <div class="col-xs-4">
        <div class="form-group">
          <label for="email">Semester:</label><?= $rsTimetable[0]['section']?>
        </div>
      </div>
  <?php }?>
    </div>
    	<div class="row table-rsponsive">
                <table class="table" border="1">
                <thead>
                    <tr>
                        <th>D/T</th>
                        <th>10 to 11</th>
                        <th>11 to 12</th>  
                        <th>12 to 01</th>
                        <th>01 to 02</th>
                        <th>02 to 03</th>
                        <th>03 to 04</th>
                        <th>04 to 05</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if(!empty($rsTimetable))
                    {
                    $i=0;
                    foreach ($rsTimetable as $value) {
                    echo '<tr>
                    <td>'.$value['days_name'].'</td>
                    ';
                    $j=1;
                    for($k=0;$k<7;$k++)
                    {
                    echo'<td>';
                        
                        foreach ($rsSubject as  $subvalue) {
                          if($value['slotsub'.$j.'']==$subvalue['SUBID'])
                          {
                            echo $subvalue['subcode'].'('.$subvalue['subname'].')';
                            echo "<br/>";
                          }
                        }
                   
                        foreach ($rsRoom as  $roomvalue) {
                          if($value['slotroom'.$j.'']==$roomvalue['RNO'])
                          {
                          	echo $roomvalue['rname'];
                            echo "<br/>";
                          }
                        }
                    
                         foreach ($rsTeacher as  $teachervalue) {
                          if($value['slotteacher'.$j.'']==$teachervalue['USER_ID'])
                          {
                          	echo $teachervalue['user_name'];
                          }
                        }
                        echo'
                    </td>';
                     $j++;

                    }
                     $i++;
                    echo'</tr>';
                  } 
              	}
                  ?>
                </tbody>
              </table>
            </div>
            <table>
              <tr><td>First row between Days&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</td><td>&nbsp;&nbsp;Subject</td></tr>
              <tr><td>Second row between Days&nbsp;:</td><td>&nbsp;&nbsp;Room Name</td></tr>
              <tr><td>Thired row between Days&nbsp;&nbsp;&nbsp;:</td><td>&nbsp;&nbsp;Teacher</td></tr>
            </table>



<?php
  $html = ob_get_contents();
  ob_end_clean();
  $mpdf->AddPage('L'); 
  $mpdf->WriteHTML($html);
  $mpdf->SetTitle("Time Table of ".$rsTimetable[0]['bname']. ' Semester '.$rsTimetable[0]['section'] );
  $mpdf->Output();
?>

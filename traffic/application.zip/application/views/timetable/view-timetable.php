<div class="col-sm-12">
	<div class="card">  
    <div class="card-header">
      <h3 class="card-title"><?= $title; ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
       <?php 
        //id or password incorrect
        if($this->session->flashdata('statusType'))
        {
            echo '<div class="alert alert-'.$this->session->statusType.' alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <p>'.$this->session->statusMsg.'</p>
                  </div>';
        }
      ?>
 
 	<div class="row">
    <?php 
//    print_r($rsTimetable);
    ?>
    <?php 
        	if(!empty($rsTimetable)){?>
      <div class="col-sm-12">
        <a name="getpdf" class="btn btn-md btn-primary"  href='<?= site_url("timetable/pdf_timetable/".$rsTimetable[0]['bid']."/".$rsTimetable[0]['section'].""); ?>' target="_blank">Get PDF</a>
      </div>
   	  <div class="col-sm-6">
        <div class="form-group">

          <label for="email">Branch:</label>
          <input type="hidden" name="branchid" value="<?= $rsTimetable[0]['bid']?>">
          <input type="text" class="form-control" value="<?= $rsTimetable[0]['bname']?>" readonly>
        </div>
      </div>
       <div class="col-sm-6">
        <div class="form-group">
          <label for="email">Semester:</label>
          <input type="hidden" name="semsterNo" value="<?= $rsTimetable[0]['section']?>">
          <input type="text" class="form-control" value="<?= $rsTimetable[0]['section']?>" readonly>
        </div>
      </div>
  <?php }?>
    </div>
    	<div class="row table-rsponsive">
                <table class="table table-border table-striped ">
                <thead>
                    <tr>
                        <th>D/T</th>
                        <th>10 to 11</th>
                        <th>11 to 12</th>  
                        <th>12 to 01</th>
                        <th>01 to 02</th>
                        <th>02 to 03</th>
                        <th>03 to 04</th>
                        <th>04 to 05</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if(!empty($rsTimetable))
                    {
                    $i=0;
                    foreach ($rsTimetable as $value) {
                    echo '<tr>
                    <td>'.$value['days_name'].'<input type="hidden" name="days[]" value="'.$value['days_name'].'"></td>
                    ';
                    echo '<input type="hidden" name="mid[]" value="'.$value['MID'].'">';
                    $j=1;
                    for($k=0;$k<7;$k++)
                    {
                    echo'<td>';
                        
                        foreach ($rsSubject as  $subvalue) {
                          if($value['slotsub'.$j.'']==$subvalue['SUBID'])
                          {
                            echo '<input type="text" class="form-control" readonly 
                            value="'.$subvalue['subcode'].'('.$subvalue['subname'].')">';
                          }
                        }
                   
                        foreach ($rsRoom as  $roomvalue) {
                          if($value['slotroom'.$j.'']==$roomvalue['RNO'])
                          {
                          	echo '<input type="text" class="form-control" readonly value="'.$roomvalue['rname'].'">';
                          }
                        }
                    
                         foreach ($rsTeacher as  $teachervalue) {
                          if($value['slotteacher'.$j.'']==$teachervalue['USER_ID'])
                          {
                          	echo '<input type="text" class="form-control" readonly value="'.$teachervalue['user_name'].'">';
                           
                          }
                        }
                        echo'
                    </td>';
                     $j++;

                    }
                     $i++;
                    echo'</tr>';
                  } 
              	}
                  ?>
                </tbody>
              </table>
            </div>
   <?php
  // echo "<pre>";
 //  print_r($rsTimetable);
   ?>
  </div>
  </form>
</div>

    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!--/.col-sm-12-->
<style>
  .error p{
    background-color: #5F5F5F;
    padding: 5px;
    color:white;
  }
</style>

<script type="text/javascript">
        $(function(){
          $('.sidebar-toggle').trigger('click');
          $('.active').removeClass("active");
          $('#pg-timetable').addClass("active");
        });
    </script>


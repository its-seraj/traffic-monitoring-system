<div class="col-sm-12">
	<div class="card">  
    <div class="card-header">
      <h3 class="card-title"><?= $title; ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
       <?php 
        //id or password incorrect
        if($this->session->flashdata('statusType'))
        {
            echo '<div class="alert alert-'.$this->session->statusType.' alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <p>'.$this->session->statusMsg.'</p>
                  </div>';
        }
      ?>
  <form action="<?= base_url('timetable/add_table')?>" method="post">
 	<div class="row">
   		<div class="col-sm-4">
        <label>Branch:</label>
   			<select name="branchid" class="form-control"> 
   				<?php
   				foreach ($rsBranch as  $value) 
   				{
   					echo '<option value ="'.$value['bid'].'">'.$value['bname'].'</option>';
   				}
   				 ?>
   			</select>
   		</div>
   		<div class="col-sm-4">
        <label>Semester:</label>
  			<select name="semsterNo" class="form-control">
  				<option value="">Select Any One</option> 
   			</select>
   		</div>
   	</div>
    <div class="timetablefield">
    </div>
  </div>
  </form>

    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!--/.col-sm-12-->
<style>
  .error p{
    background-color: #5F5F5F;
    padding: 5px;
    color:white;
  }
</style>
<script type="text/javascript">
	  $('select[name="branchid"]').change(function(){
      	 branchAjaxfun($(this).val());
	    });
	    if($('select[name="branchid"]').val()!='')
	    {
	      branchAjaxfun($('select[name="branchid"]').val());
	    }
	 function branchAjaxfun(bid)
 	 {
 	 	if(bid=='')
 	 	{
 	 		alert("Select Branch");
 	 	}
       $.ajax({
          url   : '<?= site_url('branch/get_branch_singlerow') ?>',
          method: 'post',
          data  : {bid:bid},
          dataType :'json',
          success:function(res){
           var snumber   = res.semster_no;
           var htmlValue = '<option value="">Select Any One</option>';
           for (var i = 1; i <= snumber; i++) {
              htmlValue = htmlValue+'<option value="'+i+'">'+i+'</option>';
            } 
            $('select[name="semsterNo"]').html(htmlValue);
          }
       });
  	}
  	$('select[name="semsterNo"]').change(function(){
  	var semid =	$('select[name="semsterNo"]').val();
  	var bid   =	$('select[name="branchid"]').val();
  		$.ajax({
  			url:'<?= site_url("timetable/getForm")?>',
  			data:{bid:bid,semid:semid},
  			method: 'post',
  			success: function(res)
  			{
          
          if(res==1)
          {
            window.location= "<?= site_url('timetable');?>";
          }
          else
          {
            $('.timetablefield').html(res);  
          }
  			} 
  		});
  	});
   
   
</script>
<script type="text/javascript">
        $(function(){
          $('.sidebar-toggle').trigger('click');
          $('.active').removeClass("active");
          $('#pg-timetable').addClass("active");
        });
    </script>


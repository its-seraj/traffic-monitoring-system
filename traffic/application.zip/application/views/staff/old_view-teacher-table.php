

  
<div class="col-sm-12">
	<div class="card">  
    <div class="card-header">
      <h3 class="card-title"><?= $title; ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
       <?php 
        //id or password incorrect
        if($this->session->flashdata('statusType'))
        {
            echo '<div class="alert alert-'.$this->session->statusType.' alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <p>'.$this->session->statusMsg.'</p>
                  </div>';
        }
      ?>

      <?php
      //echo "<pre>";
      //print_r($rsTable); 
      ?>
    <div class="table-responsive">
      <table class="myTable  table table-bordered table-striped">
          <thead>
            <tr>
                <th>#</th>
                <th>D/T</th>
                <th>10 to 11</th>
                <th>11 to 12</th>
                <th>12 to 01</th>
                <th>01 to 02</th>
                <th>02 to 03</th>
                <th>03 to 04</th>
                <th>04 to 05</th>
            </tr>
          </thead>
        <tbody>
         <?php
        /* echo "<pre>";
       print_r($rsTable);*/
       //  echo $roomid;
         $i=0;
         foreach ($rsTable as $value) {
           echo '<tr>
              <td>'.++$i.'</td>
              <td>'.$value['days_name'].'</td>';
              for ($k=1; $k <=7 ; $k++) { 
                if($teacherid == $value['slotteacher'.$k.''])
                { 
                  echo '<td><div class="input-group input-group-sm mb-1">
                          <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">Branch :-</span>
                          </div>
                          <input type="text" class="form-control"  placeholder="Branch" aria-label="Username" aria-describedby="basic-addon1" value="'.$value['bname'].'('.$value['section'].')">
                      </div>';
                  foreach ($rsSubject as  $subvalue) 
                  {
                    if($value['slotsub'.$k.'']==$subvalue['SUBID'])
                    {
                      echo '<div class="input-group input-group-sm mb-1">
                          <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">Subject:-</span>
                          </div>
                          <input type="text" class="form-control"  placeholder="Subject" aria-label="Username" aria-describedby="basic-addon1" value="'.$subvalue['subcode'].'('.$subvalue['subname'].')">
                      </div>';
                    }
                  }
                  foreach ($rsRoom as  $roomvalue) 
                  {
                    if($value['slotroom'.$k.'']==$roomvalue['RNO'])
                    {
                      echo '<div class="input-group input-group-sm mb-1">
                              <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-addon1">Room &nbsp;&nbsp;:-</span>
                              </div>
                              <input type="text" class="form-control"  placeholder="Teacher" aria-label="Username" aria-describedby="basic-addon1" value="'.$roomvalue['rname'].'">
                            </div>';
                    }
                  }
                  echo "</td>";
                }
                else
                {
                  echo "<td></td>";
                }
              }
              echo'</tr>';
         }
         ?>
       </tbody>
      </table>
    </div>
   </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!--/.col-sm-12-->
<style>
  .error p{
    background-color: #5F5F5F;
    padding: 5px;
    color:white;
  }
</style>
<script>
  $(document).ready( function () {
    $('.myTable').DataTable({
    
    });
  });

</script>
<script type="text/javascript">
        $(function(){
          $('.sidebar-toggle').trigger('click');
          $('.active').removeClass("active");
          $('#pg-teacher').addClass("active");
        });
    </script>


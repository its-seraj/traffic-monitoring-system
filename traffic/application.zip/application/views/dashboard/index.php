
  <script>
  paceOptions = {
  restartOnPushState: true
}
  </script>
    <!-- /.content-header -->
    <!-- Main content -->
    <?php  if($this->session->user_type!=3){ ?>
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
     
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?= count($countBranch) ?></h3>
                <p>Branch</p>
              </div>
              <div class="icon">
                <i class="fa fa-clone"></i>
              </div>
              <a href="<?= base_url('branch');?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?= count($countSubject);?></h3>
                <p>Subject</p>
              </div>
              <div class="icon">
                <i class="fa fa-book"></i>
              </div>
              <a href="<?= base_url('subject');?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>

          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?= count($countRoom);?></h3>
                <p>Room</p>
              </div>
              <div class="icon">
                <i class="fa fa-home"></i>
              </div>
              <a href="<?= base_url('room');?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <?php if($this->session->user_type==0){ ?>
           <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?= count($countTeacher);?></h3>
                <p>Teacher</p>
              </div>
              <div class="icon">
                <i class="fa fa-users"></i>
              </div>
              <a href="<?= base_url('teacher');?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-primary">
              <div class="inner">
                <h3><?= count($countStudent);?></h3>
                <p>Student</p>
              </div>
              <div class="icon">
                <i class="fa fa-graduation-cap"></i>
              </div>
              <a href="<?= base_url('student');?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        
        <?php }?>
         <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?= count($countFeedback);?></h3>
                <p>Feedback</p>
              </div>
              <div class="icon">
                <i class="fa fa-comment-o"></i>
              </div>
              <a href="<?= base_url('feedback');?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
  <?php }else{
    ?>
    <section class="content">
      <div class="container-fluid">
        <div class="col-sm-12">
        <div class="card">  
          <div class="card-header">
            <h3 class="card-title">Welcome</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <center>
              <h1>Welcome! <?= $StudentDetail['user_name'] ?></h1>
              <h5>We're glad you're here</h5>
              <?php
              if($StudentDetail['user_img']!=null && $StudentDetail['user_img']!='')
                {
                  echo '<img src="'.site_url($StudentDetail['user_img']).'" class="img-responsive" alt="'.$StudentDetail['user_name'].'" title="'.$StudentDetail['user_email'].'" width="304" height="236">';
                }
              else
                {
                    echo '<img src="'.site_url('assets/profile/user/user.png').'" class="img-circle" alt="No Photo" width="304" height="236">';
                }
              ?>
            </center>
          </div>
        </div>
      </div>
    </div>

       
      </div>
    </section>
    <?php
  } ?>

    <!-- /.content -->
    <script type="text/javascript">
        $(function(){
          $('.sidebar-toggle').trigger('click');
          $('.active').removeClass("active");
          $('#pg-dashboard').addClass("active");
        });
    </script>

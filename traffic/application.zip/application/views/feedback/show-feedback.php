<style>
  .error p{
    background-color: #5F5F5F;
    padding: 5px;
    color:white;
  }
</style>
<div class="col-sm-12">
	<div class="card">  
    <div class="card-header">
      <h3 class="card-title"><?= $title; ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
       <?php 
        //id or password incorrect
        if($this->session->flashdata('statusType'))
        {
            echo '<div class="alert alert-'.$this->session->statusType.' alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <p>'.$this->session->statusMsg.'</p>
                  </div>';
        }
      ?>
       <center>
        <?php if($this->session->user_type!=2)
        {?>
         <button type="button" class="btn btn-primary ml-3" onclick="addFeedback();">
           <i class="fa fa-plus"></i>&nbsp;Add Feedback
         </button>
       <?php }?>
      </center>
    <div class="table-responsive">
      <table class="myTable  table table-bordered table-striped">
          <thead>
            <tr>
                <th>#</th>
                <th>Feedback Message</th>
                <th>Send By</th>
                <th>Send To</th>
                <th>Time</th>
                <?php if($this->session->user_type==0){ ?>
                <th>Action</th>
              <?php } ?>
            </tr>
          </thead>
        <tbody>
          <?php
           if(!empty($rsFeedback)){
            $teacherfield= '<option value="">Select Any One</option>';
            foreach ($rsTeacher as  $value) {
              $teacherfield.= '<option value="'.$value['USER_ID'].'">'.$value['user_name'].'</option>';
            }
            echo "<div class='teachervalue' style='display:none;'>".$teacherfield."</div>";
            $i = 0;
            foreach($rsFeedback as $row){
                $link          = site_url("feedback/delete_feedback/".$row['fid']);
              echo '<tr>
                        <td>'. ++$i.'</td>
                        <td>'.$row['fmessage'].'</td>
                        <td>';
                  /*        if($rsStudent)*/
                            foreach ($rsStudent as  $value) {
                              if($value['USER_ID']==$row['sid'])
                              {
                                echo $value['user_name'];
                              }
                            }
                        echo'</td>
                        <td>';
                          /*if($rsTeacher)*/
                            foreach ($rsTeacher as  $value) {
                              if($value['USER_ID']==$row['tid'])
                              {
                                echo $value['user_name'];
                              }
                            }
                        echo '</td>
                        <td>'.$row['ftime'].'</td>';
                        if($this->session->user_type==0){
                        echo'<td><button class="btn btn-danger" onclick="deleteModal('."'".$link."'".')">
                                   <i class="fa fa-trash"></i></button>  
                         </td>';
                       }
                    echo'     
                    </tr>';
            }//foreach
           }//if
          ?>
       </tbody>
      </table>
    </div>
   </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!--/.col-sm-12-->
<style>
  .error p{
    background-color: #5F5F5F;
    padding: 5px;
    color:white;
  }
</style>
<script>
  $(document).ready( function () {
    $('.myTable').DataTable({
    
    });
  });
	function deleteModal(link)
	{
		$('.modal-title').html('Confirm');
		$('.modal-body').html('Are you sure do you really want to delete this record?');
		$('.modal-footer').html('<a href="'+link+'" class="btn btn-danger">Delete</a> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>');
		 $('#myModal').modal('show'); 
	}// fun deleteModal
  function addFeedback()
  {
    var teacherfield = $('.teachervalue').html();
    $('.modal-title').html("Add feedback");
    $('.modal-body').html('<form  id="feedbackform"><div class="row"><div class="col-sm-12 error"></div><div class="col-sm-12"><div class="form-group"><label>Teacher Name </label><select name="teacherid" class="form-control">'+teacherfield+'</select></div></div><div class="col-sm-12"><div class="form-group"><label>Message</label><textarea name="message" class="form-control"></textarea></div></div></div></form>');
    $('.modal-footer').html('<button type="button" class="btn btn-success" onclick="submitFeedback();">Send</button> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>');
    $('#myModal').modal('show'); 
    
  }
  function submitFeedback()
  {
      var url = '<?= site_url('feedback/add_feedback'); ?>';
      $.post(url,
       $('#feedbackform').serialize(),
           function(res){
            if(res==1){
              location.reload();
            }
            else{

               $('#myModal .modal-body .error').html(res);
            }
           }
      );
  }

</script>
<script type="text/javascript">
        $(function(){
          $('.sidebar-toggle').trigger('click');
          $('.active').removeClass("active");
          $('#pg-feedback').addClass("active");
        });
    </script>


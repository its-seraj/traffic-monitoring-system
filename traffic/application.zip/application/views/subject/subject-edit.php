<div class="col-sm-12">
  <div class="card">  
    <div class="card-header">
      <h3 class="card-title"><?= $title; ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
       <?php 
        //id or password incorrect
        if($this->session->flashdata('statusType'))
        {
            echo '<div class="alert alert-'.$this->session->statusType.' alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <p>'.$this->session->statusMsg.'</p>
                  </div>
            ';
        }
      ?>
      <form action="<?= base_url('subject/edit_subject')?>" method="post">
        <div class="row">
          <input type="hidden" name="subjectid" value="<?= $rowSubject['SUBID']; ?>">
          <div class="col-sm-6">
            <div class="form-group">
              <label for="Branch Name">Branch Name</label>
              <select class="form-control" name="branchid" required>
                <?php
                if($rsbranch)
                  foreach ($rsbranch as $row) {
                      if($rowSubject['bid']!=$row['bid'])
                      {
                        echo "<option value='".$row['bid']."'>".$row['bname']."</option>";    
                      }
                      else
                      {
                        echo "<option selected value='".$row['bid']."'>".$row['bname']."</option>";     
                      }
                  }
                 ?>
              </select>
              <span class="badge badge-danger"><?php echo form_error('branchid'); ?></span>
            </div>
          </div>
      
          <div class="col-sm-6">
            <div class="form-group">
              <label for="Subject Code">Semester</label>
              <select name="semsterNo" class="form-control">
                <option value="">Select Any One</option>
              </select>
              <span class="badge badge-danger"><?php echo form_error('semsterNo'); ?></span>
            </div>
          </div>
          <div class="col-sm-5">
            <div class="form-group">
              <label for="Subject Code">Subject Code</label>
              <input type="text" name="subCode" value="<?php echo $rowSubject['subcode']; ?>" class="form-control" required>
              <span class="badge badge-danger"><?php echo form_error('subCode'); ?></span>
            </div>
          </div>
          <div class="col-sm-5">
            <div class="form-group">
              <label for="Subject Code">Subject Name</label>
              <input type="text" name="subName" value="<?php echo $rowSubject['subname']; ?>" class="form-control">
              <span class="badge badge-danger"><?php echo form_error('subName'); ?></span>
            </div>
          </div>
          
          <div class="col-sm-2">
            <div class="form-group">
              <label for="Subject Code">Status</label>
               <select class="form-control" name="subStatussub" required>
                <?php
                if($rowSubject['substatus']==1)
                {
                  echo '<option selected value="1">Active</option>
                        <option value="0">Inactive</option>';
                } 
                else
                {
                  echo '<option value="1">Active</option>
                        <option selected value="0">Inactive</option>';
                }
                ?>
             
              </select>
              <span class="badge badge-danger"><?php echo form_error('subStatus'); ?></span>
            </div>
          </div>
           
        <div class="row">
          <div class="col-sm-6">
            <button type="submit" name="submit" class="btn btn-block btn-primary">Submit</button>
          </div>
          <div class="col-sm-6">
            <button type="reset" name="reset" class="btn btn-block btn-defalult">Reset</button>
          </div>
        </div><!--end of row-->
      </div>
    </form>
   </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!--/.col-sm-12-->
<style>
  .error p{
    background-color: #5F5F5F;
    padding: 5px;
    color:white;
  }
</style>
<script type="text/javascript">
  $(function(){
    $('select[name="branchid"]').change(function(){
       branchAjaxfun($(this).val(),0);
    });
    branchAjaxfun("<?php echo $rowSubject['bid']?>","<?php echo $rowSubject['semid']?>");
});

  function branchAjaxfun(bid,set)
  {
       $.ajax({
          url   : '<?= site_url('branch/get_branch_singlerow') ?>',
          method: 'post',
          data  : {bid:bid},
          dataType :'json',
          success:function(res){
           var snumber = res.semster_no;
          var content = '<option value="">Select Any One</option>';
          for (var i = 1; i <= snumber ; i++) {
            if(set!=0 && set==i)
            {
              content = content +'<option selected>'+i+'</option>';  
            }
            else
            {
              content = content +'<option>'+i+'</option>';  
            } 
          }
          $('select[name="semsterNo"]').html(content);
          }
       });
  }
  
</script>
<script type="text/javascript">
        $(function(){
          $('.sidebar-toggle').trigger('click');
          $('.active').removeClass("active");
          $('#pg-subject').addClass("active");
        });
    </script>


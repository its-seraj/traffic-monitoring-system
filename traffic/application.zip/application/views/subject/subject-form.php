<div class="col-sm-12">
	<div class="card">  
    <div class="card-header">
      <h3 class="card-title"><?= $title; ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
       <?php 
        //id or password incorrect
        if($this->session->flashdata('statusType'))
        {
            echo '<div class="alert alert-'.$this->session->statusType.' alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <p>'.$this->session->statusMsg.'</p>
                  </div>
            ';
        }
      ?>
      <form action="<?= base_url('subject/add_subject')?>" method="post">
        <div class="row">
          <div class="col-sm-6">
            <div class="form-group">
              <label for="Branch Name">Branch Name:</label>
              <select class="form-control" name="branchid" required>
                <option value="">Select Any One</option>
                <?php
                if($rsbranch)
                  foreach ($rsbranch as $row) {
                    echo "<option value='".$row['bid']."'>".$row['bname']."</option>";
                  }
                 ?>
              </select>
              <span class="badge badge-danger"><?php echo form_error('branchid'); ?></span>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <label for="Subject Code">Semester:</label>
              <select class="form-control" name="semsterNo" required>
                <option value="">Select Any One</option>

              </select>
              <span class="badge badge-danger"><?php echo form_error('semsterNo'); ?></span>
            </div>
          </div>
          <div class="col-sm-5">
            <div class="form-group">
              <label for="Subject Code">Subject Code:</label>
              <input type="text" name="subCode[]" value="<?php echo set_value('subCode[]');?>" class="form-control" required>
              <span class="badge badge-danger"><?php echo form_error('subCode[]'); ?></span>
            </div>
          </div>
          <div class="col-sm-5">
            <div class="form-group">
              <label for="Subject Code">Subject Name:</label>
              <input type="text" name="subName[]" value="<?php echo set_value('subName[]');?>" class="form-control">
              <span class="badge badge-danger"><?php echo form_error('subName[]'); ?></span>
            </div>
          </div>
          <div class="col-sm-1">
            <div class="form-group">
              <label for="Subject Code">Status:</label>
               <select class="form-control" name="subStatussub[]" required>
                <option value="1">Active</option>
                <option value="0">Inactive</option>
              </select>
              <span class="badge badge-danger"><?php echo form_error('subStatus[]'); ?></span>
            </div>
          </div>
            <div class="col-sm-1 lastAdd">
            <label style="color: white;">f</label>
             <button type="button" name="addMore" class="btn btn-md btn-primary"><i class="fa fa-plus"></i>&nbsp;&nbsp; Subject</button>
          </div><!--end of the col-sm-12-->
        </div><!--end of row-->
        <div class="extrafields row">
        </div>
        <br/>
        <div class="row">
          <div class="col-sm-6">
            <button type="submit" name="submit" class="btn btn-block btn-primary">Submit</button>
          </div>
          <div class="col-sm-6">
            <button type="reset" name="reset" class="btn btn-block btn-defalult">Reset</button>
          </div>
        </div><!--end of row-->
      </form>
   </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!--/.col-sm-12-->
<style>
  .error p{
    background-color: #5F5F5F;
    padding: 5px;
    color:white;
  }
</style>
<script type="text/javascript">
  $(function(){
    $("button[name='addMore']").click(function(){
      $('.extrafields').append('<div class="col-sm-12 removeExtrafield"><div class="row"><div class="col-sm-5"><div class="form-group"><label for="Subject Code">Subject Code</label><input type="text" name="subCode[]" value="<?php echo set_value('subCode[]');?>" class="form-control" required><span class="badge badge-danger"><?php echo form_error('subCode[]'); ?></span></div></div><div class="col-sm-5"><div class="form-group"><label for="Subject Code">Subject Name</label><input type="text" name="subName[]" value="<?php echo set_value('subName[]');?>" class="form-control"><span class="badge badge-danger"><?php echo form_error('subName[]'); ?></span></div></div><div class="col-sm-1"><div class="form-group"><label for="Subject Code">Status</label><select class="form-control" name="subStatussub[]" required><option value="1">Active</option><option value="0">Inactive</option></select><span class="badge badge-danger"><?php echo form_error('subStatussub[]'); ?></span></div></div><div class="col-sm-1"><span class="input-group-addon btn btn-danger " onclick="close_url(this);" style="cursor:pointer; height:45px;width:50px; margin-top:35px;">X</span></div></div></div>');
    });
    
    $('select[name="branchid"]').change(function(){
       branchAjaxfun($(this).val());
    });
    if($('select[name="branchid"]').val()!='')
    {
      branchAjaxfun($('select[name="branchid"]').val());
    }
    if($('input[name="branchid"]').val()!=undefined)
    {
      branchAjaxfun($('input[name="branchid"]').val());
    }
  });
  function close_url(a)
  {
    $(a).parents('.removeExtrafield').remove();
  }
  function branchAjaxfun(bid)
  {
       $.ajax({
          url   : '<?= site_url('branch/get_branch_singlerow') ?>',
          method: 'post',
          data  : {bid:bid},
          dataType :'json',
          success:function(res){
           var snumber   = res.semster_no;
           var htmlValue = '<option value="">Select Any One</option>';
           for (var i = 1; i <= snumber; i++) {
              htmlValue = htmlValue+'<option value="'+i+'">'+i+'</option>';
            } 
            $('select[name="semsterNo"]').html(htmlValue);
          }
       });
  }
  
</script>
<script type="text/javascript">
        $(function(){
          $('.sidebar-toggle').trigger('click');
          $('.active').removeClass("active");
          $('#pg-subject').addClass("active");
        });
    </script>


<div class="col-sm-12">
	<div class="card">  
    <div class="card-header">
      <h3 class="card-title"><?= $title; ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
       <?php 
        //id or password incorrect
        if($this->session->flashdata('statusType'))
        {
            echo '<div class="alert alert-'.$this->session->statusType.' alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <p>'.$this->session->statusMsg.'</p>
                  </div>
            ';
        }
      ?>
       <center>
        <?php if($this->session->user_type!=2){ ?>
         <a class="btn btn-primary ml-3" href="<?=base_url("subject/subject_form")?>">
          <i class="fa fa-plus"></i>&nbsp;&nbsp;Add Subject
        </a>
      <?php } ?>
      </center>
    <div class="table-responsive">
      <table class="myTable  table table-bordered table-striped">
          <thead>
            <tr>
                <th>#</th>
                <th>Subject Code</th>
                <th>Subject Name</th>
                <th>Branch Name</th>
                <th>Semester</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
          </thead>
        <tbody>
          <?php
           if(!empty($rsSubject)){
            $i = 0;
            foreach($rsSubject as $row){
              $link      = site_url("subject/delete_subject/".$row['SUBID']);
              $tableLink = site_url("subject/view_table/".$row['SUBID']);
              $pdflink   = site_url("subject/pdf_timetable/".$row['SUBID']);
              echo '<tr>
                        <td>'.++$i.'</td>
                        <td>'.$row['subcode'].'</td>
                        <td>'.$row['subname'].'</td>
                        <td>'.$row['bname'].'</td>
                        <td>'.$row['semid'].'</td>
                        <td>';
                           if($row['substatus']==1){
                            echo '<small class="badge badge-success">Active</small>';
                           }else{
                            echo '<small class="badge badge-danger">Inactive</small>';
                           }
                   echo '</td><td>';
                  if($this->session->user_type!=2){ 

                   echo '
                            <a class="btn btn-primary" href="'.base_url("subject/edit_subject_form/".$row['SUBID']).'">
                                <i class="fa fa-edit"></i>
                            </a>

                            <button class="btn btn-danger" onclick="deleteModal('."'".$link."'".')">
                             <i class="fa fa-trash"></i>
                            </button> 
                            ';
                            }echo'
                             <a class="btn btn-success" href="'.$tableLink.'" title="View Table">
                             <i class="fa fa-eye"></i></a> 
                             <a href="'.$pdflink.'" class="btn btn-info btn-md"><i class="fa fa-file"></i></a>

                         </td>         
                    </tr>';
            }//foreach
           }//if
          ?>
       </tbody>
      </table>
    </div>
   </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!--/.col-sm-12-->
<style>
  .error p{
    background-color: #5F5F5F;
    padding: 5px;
    color:white;
  }
</style>
<script>
  $(document).ready( function () {
    $('.myTable').DataTable({
    
    });
  });
//=========================Delete package==============================
	function deleteModal(link)
	{
		$('.modal-title').html('Confirm');
		$('.modal-body').html('Are you sure do you really want to delete this record?');
		$('.modal-footer').html('<a href="'+link+'" class="btn btn-danger">Delete</a> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>');
		 $('#myModal').modal('show'); 
	}// fun deleteModal
//-------------------------------------------------------------


</script>
<script type="text/javascript">
        $(function(){
          $('.sidebar-toggle').trigger('click');
          $('.active').removeClass("active");
          $('#pg-subject').addClass("active");
        });
    </script>




  
<div class="col-sm-12">
	<div class="card">  
    <div class="card-header">
      <h3 class="card-title"><?= $title; ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
       <?php 
        //id or password incorrect
        if($this->session->flashdata('statusType'))
        {
            echo '<div class="alert alert-'.$this->session->statusType.' alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <p>'.$this->session->statusMsg.'</p>
                  </div>';
        }
      ?>
       <center>
        <?php
             if($this->session->user_type!=2)
                   {
        ?>
         <button class="btn btn-primary ml-3" onclick="addRoom();">
          <i class="fa fa-plus"></i>&nbsp;Add Room
        </button>
      <?php }
      ?>
      </center>
      <div class="subjectdata" style="display: none;">
          <select name="room_status[]" class="form-control">
            <option value="1">Active</option>
            <option value="0">InActive</option>
          </select>
      </div>
    <div class="table-responsive">
      <table class="myTable  table table-bordered table-striped">
          <thead>
            <tr>
                <th>#</th>
                <th>Room Name</th>
                <th>Room Type</th>
                <th>Room Floor</th>
                <th>Status</th>
                <th width="13%">Action</th>
            </tr>
          </thead>
        <tbody>
          <?php
           if(!empty($rsRoom)){
            $i = 0;
            foreach($rsRoom as $row){

              $link    = site_url("room/delete_room/".$row['RNO']);
              $tableLink = site_url("room/view_table/".$row['RNO']);
              $pdflink  = site_url("room/pdf_timetable/".$row['RNO']);
            
              echo '<tr>
                        <td>';
                        echo ++$i;
                        echo '</td>
                        <td>'.$row['rname'].'</td>
                        <td>'.$row['rtype'].'</td>
                        <td>'.$row['rfloor'].'</td>
                        <td >';
                           if($row['status']==1){
                            echo '<small class="badge badge-success">Assiged</small>';
                           }else{
                            echo '<small class="badge badge-danger">Not Assiged</small>';
                           }
                   echo '</td>';
                   echo '<td style="width:200px;">';
                   if($this->session->user_type!=2)
                   {
                        echo'
                            <button class="btn btn-primary" onclick="editModal('."'".$row['RNO']."'".','."'".$row['rname']."'".','."'".$row['rtype']."'".','."'".$row['rfloor']."'".','."'".$row['status']."'".')">
                                <i class="fa fa-edit"></i>
                            </button>&nbsp;';
                             echo '<button class="btn btn-danger" onclick="deleteModal('."'".$link."'".')">
                             <i class="fa fa-trash"></i>
                            </button> ';
                    }
                            echo'
                            <a class="btn btn-success" href="'.$tableLink.'" title="View Table">
                             <i class="fa fa-eye"></i>
                            </a>&nbsp;<a class="btn btn-info" href="'.$pdflink.'" title="Pdf Table">
                             <i class="fa fa-file"></i>
                            </a>';
                  echo'</td>         
                    </tr>';
            }//foreach
           }//if
          ?>
       </tbody>
      </table>
    </div>
   </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!--/.col-sm-12-->
<style>
  .error p{
    background-color: #5F5F5F;
    padding: 5px;
    color:white;
  }
   .mandatory
        {
          color: red;
          font-size: 18px;
          font-weight: bolder;
        }
</style>
<script>
  $(document).ready( function () {
    $('.myTable').DataTable({
    
    });
  });
//=========================Delete room==============================
	function deleteModal(link)
	{
		$('.modal-title').html('Confirm');
		$('.modal-body').html('Are you sure do you really want to delete this record?');
		$('.modal-footer').html('<a href="'+link+'" class="btn btn-danger">Delete</a> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>');
		 $('#myModal').modal('show'); 
	}// fun deleteModal
//-------------------------------------------------------------
  function addRoom()
  {
   $('.modal-title').html('Add Room');
   var selectrow =$('.subjectdata').html();
    $('.modal-body').html('<form id="roomform"><div class="error"></div><div class="row"><div class="col-sm-3"><div class="form-group"><label for ="Room Name"> Room Name: <span class="mandatory">*</span></label><input type="text" class="form-control" name="room_name[]"></div></div><div class="col-sm-3"><div class="form-group"><label for ="Room Type"> Room Type: </label><input type="text" class="form-control" name="room_type[]"></div></div><div class="col-sm-2"><div class="form-group"><label for ="Room Floor"> Room Floor: </label><input type="text" class="form-control" name="room_floor[]"></div></div><div class="col-sm-2"><div class="form-group"><label>Status:</label><select name="room_status[]" class="form-control"><option value="1">Active</option><option value="0">InActive</option></select></div></div><div class="col-sm-2"><div class="form-group"><label for ="Room Name" style="color: white;">: </label><button type="button" class="btn btn-block btn-primary" onclick=addroommore();><span class="fa fa-plus"></span>&nbsp;Add More</button></div></div></div>');
    $('#myModal .modal-footer').html('<button name="" class="btn btn-md btn-success" onclick="submitroomform();">Submit</button><button class="btn btn-md btn-default" data-dismiss="modal">Close</button></form>')
    $('#myModal').modal({backdrop:'static'}); 
  } 
 function addroommore()
 { //alert("hello");
    var selectrow =$('.subjectdata').html();
    $('form').append('<div class="row"><div class="col-sm-3"><div class="form-group"><label for ="Room Name"> Room Name: <span class="mandatory">*</span></label><input type="text" class="form-control" name="room_name[]"></div></div><div class="col-sm-3"><div class="form-group"><label for ="Room Type"> Room Type: </label><input type="text" class="form-control" name="room_type[]"></div></div><div class="col-sm-2"><div class="form-group"><label for ="Room Floor"> Room Floor: </label><input type="text" class="form-control" name="room_floor[]"></div></div><div class="col-sm-2"><div class="form-group"><label>Status:</label><select name="room_status[]" class="form-control"><option value="1">Active</option><option value="0">InActive</option></select></div></div><div class="col-sm-2"><div class="form-group"><label for ="Room Name" style="color: white;">: </label><span class="input-group-addon btn btn-danger " onclick="close_url(this);" style="cursor:pointer; height:45px;width:50px; margin-top:35px;">X</span></div></div></div>');
 }
  function editModal(rno,rname,rtype,rfloor,rstatus)
  {
    if(rstatus==1)
    {
      var select = '<select name="room_status" class="form-control"><option value="1" selected>Active</option><option value="0">InActive</option></select>';
    }
    else
    {
      var select = '<select name="room_status" class="form-control"><option value="1">Active</option><option value="0" selected>InActive</option></select>';
    }
     $('.modal-title').html('Edit Room');
     $('.modal-body').html('<form id="roomEditform"><input type="hidden" name="rno" value="'+rno+'"><div class="error"></div><div class="row"><div class="col-sm-3"><div class="form-group"><label for ="Room Name"> Room Name: </label><input type="text" class="form-control" name="room_name" value="'+rname+'"></div></div><div class="col-sm-3"><div class="form-group"><label for ="Room Name"> Room Type: </label><input type="text" class="form-control" name="room_type" value="'+rtype+'"></div></div><div class="col-sm-3"><div class="form-group"><label for ="Room Name"> Room Floor: </label><input type="text" class="form-control" name="room_floor" value="'+rfloor+'"></div></div><div class="col-sm-3"><div class="form-group"><label>Status:</label>'+select+'</div></div></div>');
     $('#myModal .modal-footer').html('<button name="" class="btn btn-md btn-success" onclick="submitroomeditform();">Submit</button><button class="btn btn-md btn-default" data-dismiss="modal">Close</button></form>')
     $('#myModal').modal({backdrop:'static'}); 
  }
 

 function close_url(a)
 {
    $(a).parents('.row').remove();
 }

function submitroomform()
{
   var url = '<?= site_url('room/add_room'); ?>';
    $.post(url,
     $('#roomform').serialize(),
         function(res){
          if(res==1){
            location.reload();
          }
          else{
             $('#myModal .modal-body .error').html(res);
             }
         }
    );
}
function submitroomeditform()
{
   var url = '<?= site_url('room/edit_room'); ?>';
    $.post(url,
     $('#roomEditform').serialize(),
         function(res){
          if(res==1){
            location.reload();
          }
          else{
             $('#myModal .modal-body .error').html(res);
             }
         }
    );
}


</script>
<script type="text/javascript">
        $(function(){
          $('.sidebar-toggle').trigger('click');
          $('.active').removeClass("active");
          $('#pg-room').addClass("active");
        });
    </script>


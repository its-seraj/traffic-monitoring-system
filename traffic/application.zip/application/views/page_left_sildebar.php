
  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?= site_url('dashboard'); ?>" class="brand-link">
      <img src="<?php echo base_url('assets/images/image.png') ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light" style="font-size: 18px;">Time Table Generator</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <?php 
          if($this->session->user_img !='' && $this->session->user_img !=null)
          {
            echo '<img src="'.base_url($this->session->user_img).'" class="img-circle elevation-2" alt="User Image">';
          }
          else
          {
             echo '<img src="'.base_url("assets/profile/user/user.png").'" class="img-circle elevation-2" alt="User Image">';
          }?>
        </div>
        <div class="info">
          <a href="<?= base_url("profile")?>" class="d-block"><?= $this->session->user_name; ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview">
            <a href="<?= base_url('dashboard');?>" class="nav-link" id="pg-dashboard">
              <i class="nav-icon fa fa-dashboard"></i>
                <p>
                  Dashboard
                </p>
            </a>
          </li>
          <li class="nav-item has-treeview">
            <a href="<?= base_url('timetable/current');?>" class="nav-link" id="pg-current">
              <i class="nav-icon fa fa-search"></i>
                <p>
                  Current
                </p>
            </a>
          </li>
        <?php if($this->session->user_type==2){ ?>
           <li class="nav-item has-treeview">
            <a href="<?= base_url("teacher/my_time_table");?>" class="nav-link" id="pg-mytimetable">
              <i class="nav-icon fa fa-vcard"></i>
                <p>
                  My Time Table
                </p>
            </a>
          </li>
      <?php } ?>
       <?php if($this->session->user_type==3){ ?>
           <li class="nav-item has-treeview">
            <a href="<?= base_url("student/my_time_table");?>" class="nav-link" id="pg-mytimetable">
              <i class="nav-icon fa fa-vcard"></i>
                <p>
                  My Time Table
                </p>
            </a>
          </li>
      <?php } ?>
     
          <?php if($this->session->user_type==0){ ?>

            <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-gear"></i>
              <p>
                Setting
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item has-treeview">
            <a href="<?= base_url("branch");?>" class="nav-link" id="pg-branch">
              <i class="nav-icon fa fa-clone"></i>
                <p>
                  Branch
                </p>
            </a>
          </li>
           <li class="nav-item has-treeview">
            <a href="<?= base_url("teacher");?>" class="nav-link" id="pg-teacher">
              <i class="nav-icon fa fa-users"></i>
                <p>
                  Teacher
                </p>
            </a>
          </li>
           <li class="nav-item has-treeview">
            <a href="<?= base_url("student");?>" class="nav-link" id="pg-student">
              <i class="nav-icon fa fa-graduation-cap"></i>
                <p>
                  Student
                </p>
            </a>
          </li>
        <?php }if($this->session->user_type!=3 ) {?>
          <li class="nav-item has-treeview ">
            <a href="<?= base_url("subject");?>" class="nav-link" id="pg-subject">
              <i class="nav-icon fa fa-book"></i>
                <p>
                  Subject
                </p>
            </a>
          </li>
          <li class="nav-item has-treeview ">
            <a href="<?= base_url("room");?>" class="nav-link" id="pg-room">
              <i class="nav-icon fa fa-home"></i>
                <p>
                  Room
                </p>
            </a>
          </li>
        <?php }?>
            </ul>
          </li>
                        
          <li class="nav-item has-treeview ">
              <a href="<?= base_url('timetable')?>" class="nav-link client" id="pg-timetable">
                <i class="nav-icon fa fa-table"></i>
                <p>
                  Time Table
                </p>
              </a>
          </li>
          <li class="nav-item has-treeview ">
              <a href="<?= base_url('feedback')?>" class="nav-link client" id="pg-feedback">
                <i class="nav-icon fa fa-comment-o"></i>
                <p>
                  Feedback
                </p>
              </a>
          </li>

        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

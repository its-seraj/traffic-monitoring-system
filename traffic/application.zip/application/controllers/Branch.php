<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Branch extends MY_Controller 
{
    public function __construct()
    {
        parent::__construct();
        $this->isNotLoggedIn();
        $this->load->library('form_validation');
        $this->load->model("branch_model");
        $this->load->model("user_model");
    }
    public function index()
    {
			$data['title']="Branch";
			$data['breadcrumbs'] = array(
			 'Home' => site_url('dashboard'),
			 'Branch' => '',
				);
			$data['user'] = $this->user_model->user_detail($this->session->uid);
			$data['rsbranch']=$this->branch_model->getBranch();
	    	$this->load->view('page_header',$data);
			$this->load->view('page_left_sildebar');
			$this->load->view("branch/show-branch");
			$this->load->view('page_footer');
    }// end function index
    //==============add branch ================
    public function add_branch()
    {
        $this->form_validation->set_error_delimiters('<p class="alert alert-danger">', '</p>');
        $this->form_validation->set_rules('branch_name','Branch Name','required');
        $this->form_validation->set_rules('semster_no','Semster Number','required|numeric');
        $this->form_validation->set_rules('branch_status','Brach Status','required');
        if($this->form_validation->run()==TRUE)
        {
            $branchID = $this->branch_model->insert_branch();
            $msg = array('statusType'=>'success','statusMsg'=>'Branch Successfully Inserted');
            $this->session->set_flashdata($msg); 
            echo "1";
        }
        else
        {
            echo validation_errors();
        }
    }
    //--------------end of add branch-------

    //==============delete branch ================
    public function delete_branch($bid)
	{
	   $this->branch_model->delete_branch($bid);
       $msg = array('statusType'=>'success','statusMsg'=>'Record Deleted Successfully.');
	   $this->session->set_flashdata($msg);
	   redirect('branch');
	}
    //--------------end of delete branch-------
    //=========Get single record for edit========
    public function get_branch_singlerow()
    {
        $bid = $this->input->post('bid');
        $data['rowBranch'] = $this->branch_model->getBranch($bid);
        echo json_encode(array("bname"=>$data['rowBranch']['bname'],'bstatus'=>$data['rowBranch']['bstatus'],'branch_id'=>$data['rowBranch']['bid'],'semster_no'=>$data['rowBranch']['semster_no']));
    }
    //--------------end of Get single record for edit-------
    //===================edit brnch============
    public function edit_branch()
    {
        $this->form_validation->set_error_delimiters('<p class="alert alert-danger">', '</p>');
        $this->form_validation->set_rules('branch_name','Branch Name','required');
        $this->form_validation->set_rules('semster_no','Semster Number','required|numeric');
        $this->form_validation->set_rules('branch_status','Brach Status','required');
         if($this->form_validation->run()==TRUE)
        {
           $branchID = $this->branch_model->update_branch();
           $msg = array('statusType'=>'success','statusMsg'=>'Branch Successfully Updated');
            $this->session->set_flashdata($msg); 
            echo "1";
        }
        else
        {
            echo validation_errors();
        }
    }
    //----------end of the edit branch-----
    
}// class LoginController

?>
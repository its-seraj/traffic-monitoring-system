<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	    $this->load->helper(array('url','form','date'));
	    $this->load->database();
	  	$this->load->library('session');
	  	$this->load->model('user_model');
	  	$this->load->model('branch_model');
	  	$this->load->model('subject_model');
		$this->load->model('room_model');
		$this->load->model('student_model');
	  	$this->load->model('teacher_model');
	  	$this->load->model('feedback_model');
	}
	public function index()
	{
		if($this->session->user_email)
		{
		$data['title']="Dashboard";
		$data['breadcrumbs'] = array(
			 'Home' => '',
				);
		$data['countBranch']	= $this->branch_model->getBranch();
		$data['countSubject'] 	= $this->subject_model->getSubject();
		$data['countRoom']		= $this->room_model->getRoom();
		$data['countTeacher'] 	= $this->teacher_model->getTeacher();
		$data['countStudent'] 	= $this->student_model->getStudent();
		$data['countFeedback']  = $this->feedback_model->getFeedback($this->session->uid);
		if($this->session->user_type==3)
		{
			$data['StudentDetail'] 	= $this->student_model->getStudent($this->session->uid);
		}
		$this->load->view('page_header',$data);
		$this->load->view('page_left_sildebar');
		$this->load->view("Dashboard/index");
		$this->load->view('page_footer');
		}
		else
		{
			  $msg = array('statusType'=>'danger','statusMsg'=>'Session Is not create for some resion');
                    $this->session->set_flashdata($msg); 
			redirect("");
		}
	}

}
?>
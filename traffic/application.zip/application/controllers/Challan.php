<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Challan extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->isNotLoggedIn();
	    $this->load->helper(array('url','form','date'));
	    $this->load->database();
	  	$this->load->model('station_model');
	  	$this->load->model('area_model');
	  	$this->load->model('challan_model');
	  	$this->load->model('user_model');
	  	$this->load->library("form_validation");
	}
	public function index()
	{
			$data['title']="Challan";
			$data['breadcrumbs'] = array(
			 'Home' => site_url('dashboard'),
			 'Challan' => '',
				);
			$data['user'] = $this->user_model->user_detail($this->session->uid);
			$data['rsChallan'] =$this->challan_model->getChallan();
	    	$this->load->view('page_header',$data);
			$this->load->view('page_left_sildebar');
			$this->load->view("challan/show-challan");
			$this->load->view('page_footer');
	} //end of view class
	public function delete_challan($challanno)
	{
	   $this->challan_model->delete_challan($challanno);
       $msg = array('statusType'=>'success','statusMsg'=>'Record Deleted successfully.');
	   $this->session->set_flashdata($msg);
	   redirect('challan');
	}//delete_area

	public function challan_form()
	{
		$data['title']="Add Challan";
		$data['user'] = $this->user_model->user_detail($this->session->uid);
		$data['breadcrumbs'] = array(
			 'Home' => site_url('dashboard'),
			 'Challan' => site_url("challan"),
			 'Add Challan'=>'',
				);
			$data['rsvehicle']=$this->challan_model->getVehicle();
			$this->load->view('page_header',$data);
			$this->load->view('page_left_sildebar');
			$this->load->view("challan/challan-form");
			$this->load->view('page_footer');
	}//this is for add the area form
	public function add_challan()
	{
		$this->form_validation->set_rules('chaCode[]','Challan Code','required');
		$this->form_validation->set_rules('chaName[]','Challan ','required');
		$this->form_validation->set_rules('chaStatus[]','Challan Status','required');
		if($this->form_validation->run()==TRUE)
		{
			$challanid['chaid'] =$this->challan_model->insert_challan();	
			if($challanid)
			{
				$msg = array('statusType'=>'success','statusMsg'=>'Record Inserted successfully.');
	   			$this->session->set_flashdata($msg);
				$this->index();
			}
			else
			{
				$msg = array('statusType'=>'danger','statusMsg'=>'Some problam occurs record not inserted.');
				$this->session->set_flashdata($msg);
				$this->index();
			}
		}
		else
		{
			$this->challan_form();
		}
	}
	 public function get_challan_singlerow()
    {
        $sno = $this->input->post('sno');
        $data['rowarea'] 	=   $this->area_model->getarea($bid=null,$sno);
        $data['rsbranch']  		= 	$this->branch_model->getBranch();
       
        echo json_encode(array(
        		"area"=>array(
        			"Name"		=>	$data['rowarea']['sub_name'],
        			"branchid"	=>	$data['rowarea']['sub_branchid'],
        			"semester"	=>	$data['rowarea']['sub_semester'],
        			"status"	=>	$data['rowarea']['sub_status'],
        		),
        		"Branch"=>$data['rsbranch'],
        	));
    }
    public function get_area_record()
    {
    	 $data['rowarea'] 	=   $this->area_model->getarea();
    	 echo  json_encode($data);
    }//for the ajax value idn question added form
     public function edit_challan_form($challanno)
    {
       	$data['rowChallan']=$this->challan_model->getChallan($challanno=$challanno);
       	$data['title']="Edit Challan";
		$data['rsvehicle']=$this->challan_model->getVehicle();
		$data['breadcrumbs'] = array(
			 'Home' => base_url('dashboard'),
			 'Challan' => site_url("challan"),
			 'Edit Challan'=>'',
			);
       	$this->load->view('page_header',$data);
       	$this->load->view('page_left_sildebar');
		$this->load->view("challan/challan-edit");
		$this->load->view('page_footer');
    }
    public function edit_challan()
    {

    	$this->form_validation->set_rules('challanid','Challan ID','required');
		$this->form_validation->set_rules('chaCode','Challan Code','required');
		$this->form_validation->set_rules('chaName','Challan Description','required');
		$this->form_validation->set_rules('chaStatus','Challan Status','required');
		if($this->form_validation->run()==TRUE)
		{
			$chaid['chaid'] =$this->challan_model->update_challan();	
			$msg = array('statusType'=>'success','statusMsg'=>'Record Updated successfully.');
   			$this->session->set_flashdata($msg);
			$this->index();
		}
		else
		{
			$this->edit_area_form($this->input->post('areaid'));
		}
    }
    public function view_table($subid)
    {
        $data['rsTable'] = $this->timetable_model->gettable($bid=null,$semid=null,$roomid=null,$teacherid=null,$areaid=$subid);
        $data['title']="area";
        $data['breadcrumbs'] = array(
         'Home' => site_url('dashboard'),
         'area' => site_url('area'),
         'View Table' => ''
            );
        $data['rsRoom']=$this->room_model->getRoom();
        $data['rsarea'] = $this->area_model->getarea();
        $data['rsTeacher'] = $this->teacher_model->getTeacher();
        $data['areaid'] = $subid;
        $this->load->view('page_header',$data);
        $this->load->view('page_left_sildebar');
        $this->load->view("area/view-area-table");
        $this->load->view('page_footer');
    }
    public function pdf_timetable($subid)
    {
    	 $data['rsTable'] = $this->timetable_model->gettable($bid=null,$semid=null,$roomid=null,$teacherid=null,$areaid=$subid);
        $data['rsRoom']=$this->room_model->getRoom();
        $data['rsarea'] = $this->area_model->getarea();
        $data['rsTeacher'] = $this->teacher_model->getTeacher();
        $data['areaid'] = $subid;
        $this->load->view("area/pdf-area",$data);
    }

}
?>
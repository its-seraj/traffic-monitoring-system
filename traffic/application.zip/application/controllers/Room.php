<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Room extends MY_Controller 
{
    public function __construct()
    {
        parent::__construct();
        $this->isNotLoggedIn();
        $this->load->library('form_validation');
        $this->load->model("branch_model");
        $this->load->model("room_model");
        $this->load->model("subject_model");	
        $this->load->model("teacher_model");
        $this->load->model("timetable_model");
        $this->load->model("user_model");
    }
    public function index()
	{
		$data['title']="Room";
		$data['breadcrumbs'] = array(
		 'Home' => site_url('dashboard'),
		 'Room' => '',
			);
		$data['rsRoom']=$this->room_model->getRoom();
		$data['rsSubject'] = $this->subject_model->getSubject();
    	$this->load->view('page_header',$data);
		$this->load->view('page_left_sildebar');
		$this->load->view("room/show-room");
		$this->load->view('page_footer');
    }// end function index
    public function delete_room($rno)
	{
	   $this->room_model->delete_rom($rno);
       $msg = array('statusType'=>'success','statusMsg'=>'Record Deleted successfully.');
	   $this->session->set_flashdata($msg);
	   redirect('room');
	}//delete_subject
	public function add_room()
	{
		$this->form_validation->set_error_delimiters('<p class="alert alert-danger">', '</p>');
        $this->form_validation->set_rules('room_name[]','Room Name','required');
        $this->form_validation->set_rules('room_status[]','Room Status','required');
        if($this->form_validation->run()==TRUE)
        {
            $roomID = $this->room_model->insert_room();
            $msg = array('statusType'=>'success','statusMsg'=>'Room Successfully Inserted');
            $this->session->set_flashdata($msg); 
            echo "1";
        }
        else
        {
            echo validation_errors();
        }	
	}
    public function view_table($roomid)
    {
        $data['rsTable'] = $this->timetable_model->gettable($bid=null,$semid=null,$roomid=$roomid);
        $data['title']="Room";
        $data['breadcrumbs'] = array(
         'Home' => site_url('dashboard'),
         'Room' => site_url('room'),
         'View Table' => ''
            );
        $data['rsRoom']=$this->room_model->getRoom();
        $data['rsSubject'] = $this->subject_model->getSubject();
        $data['rsTeacher'] = $this->teacher_model->getTeacher();
        $data['roomid'] = $roomid;
        $this->load->view('page_header',$data);
        $this->load->view('page_left_sildebar');
        $this->load->view("room/view-room-table");
        $this->load->view('page_footer');
    }
    public function edit_room()
    {
        $this->form_validation->set_error_delimiters('<p class="alert alert-danger">', '</p>');
        $this->form_validation->set_rules('room_name','Room Name','required');
        $this->form_validation->set_rules('room_status','Room Status','required');
        if($this->form_validation->run()==TRUE)
        {
            $roomID = $this->room_model->update_room();
            $msg = array('statusType'=>'success','statusMsg'=>'Room Successfully Updated');
            $this->session->set_flashdata($msg); 
            echo "1";
        }
        else
        {
            echo validation_errors();
        }   
    }
    public function checkroomable()
    {

        $this->form_validation->set_error_delimiters('<p class="alert alert-danger">', '</p>');
        $this->form_validation->set_rules('id','Room No','required');
        $this->form_validation->set_rules('daysname','Days Name','required');
        $this->form_validation->set_rules('columcount','Column Name','required');
        if($this->form_validation->run()==TRUE)
        {
            $roomdetails = $this->room_model->check_room();
            echo json_encode($roomdetails);
        
        }
        else
        {
            echo validation_errors();
        }   
    }
    public function checkroomableedit()
    {
       $this->form_validation->set_error_delimiters('<p class="alert alert-danger">', '</p>');
        $this->form_validation->set_rules('id','Room No','required');
        $this->form_validation->set_rules('daysname','Days Name','required');
        $this->form_validation->set_rules('columcount','Column Name','required');
        $this->form_validation->set_rules('branchid','Branch Name','required');
        $this->form_validation->set_rules('semsterNo','Semester Name','required');
        if($this->form_validation->run()==TRUE)
        {
            $roomdetails = $this->room_model->check_room();
            if($roomdetails[0]['class']==$this->input->post("branchid") && $roomdetails[0]['section']==$this->input->post("semsterNo"))
            {
            }
            else
            {
                echo json_encode($roomdetails);    
            }
        }
        else
        {
            echo validation_errors();
        }    
    }
    public function pdf_timetable($roomid)
    {
        $data['rsTable'] = $this->timetable_model->gettable($bid=null,$semid=null,$roomid=$roomid);
        $data['rsRoom']=$this->room_model->getRoom();
        $data['rsSubject'] = $this->subject_model->getSubject();
        $data['rsTeacher'] = $this->teacher_model->getTeacher();
        $data['roomid'] = $roomid;
        $this->load->view("room/pdf-room",$data);
    }
} 
?>
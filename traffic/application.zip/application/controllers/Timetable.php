<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Timetable extends MY_Controller 
{
    public function __construct()
    {
        parent::__construct();
        $this->isNotLoggedIn();
        $this->load->library('form_validation');
        $this->load->model("branch_model");
        $this->load->model("timetable_model");
        $this->load->model("user_model");
        $this->load->model("subject_model");
        $this->load->model("room_model");
        $this->load->model("teacher_model");
    }
    public function index()
    {
			$data['title']="Time table";
			$data['breadcrumbs'] = array(
			 'Home' => site_url('dashboard'),
			 'Time Table' => '',
				);
            $data['rsTimetable'] = $this->timetable_model->getTimetable();
			$this->load->view('page_header',$data);
			$this->load->view('page_left_sildebar');
			$this->load->view("timetable/show-timetable");
			$this->load->view('page_footer');
    }// end function index
    //==============add timetable ================
    public function addtimetable()
    {
            $data['title']="Time Table";
            $data['breadcrumbs'] = array(
             'Home' => site_url('dashboard'),
             'Time Table' => site_url('timetable'),
             'Add Time Table'=> ''
                );
            $data['rsBranch'] = $this->branch_model->getBranch();
            $this->load->view('page_header',$data);
            $this->load->view('page_left_sildebar');
            $this->load->view("timetable/add-timetable");
            $this->load->view('page_footer');
    }
    public function add_table()
    {

        $this->timetable_model->insert_timetable();
        $msg = array('statusType'=>'success','statusMsg'=>'Record Inserted successfully.');
        $this->session->set_flashdata($msg);
        $this->index();    

    }
    public function delete_timetable($bid,$sno)
    {

       $this->timetable_model->delete_time($bid,$sno);
       $msg = array('statusType'=>'success','statusMsg'=>'Record Deleted successfully.');
       $this->session->set_flashdata($msg);
       redirect('timetable');
    }
    public function edit_timetable($bid,$semid)
    {
         
         $data['title']="Time Table";
            $data['breadcrumbs'] = array(
            'Home' => site_url('dashboard'),
             'Time Table' => site_url('timetable'),
             'Edit Time Table' => '',
                );
            $data['rsTimetable'] = $this->timetable_model->getTimetable($bid,$semid);
            $data['rsBranch'] = $this->branch_model->getBranch();
            $data['rsSubject'] = $this->subject_model->getSubject($bid=$bid,$sid=null,$sno=$semid);
            $data['rsTeacher'] = $this->teacher_model->getTeacher();
            $data['rsRoom'] = $this->room_model->getRoom();
            $this->load->view('page_header',$data);
            $this->load->view('page_left_sildebar');
            $this->load->view("timetable/edit-timetable");
            $this->load->view('page_footer');
    }
    public function edit_table()
    {
         $this->timetable_model->update_timetable(); 
         $msg = array('statusType'=>'success','statusMsg'=>'Record Updated successfully.');
         $this->session->set_flashdata($msg);
         $this->index();    
    }
    public function view_timetable($bid,$semid)
    {
           $data['title']="Time Table";
            $data['breadcrumbs'] = array(
             'Home' => site_url('dashboard'),
             'Time Table' => site_url('timetable'),
             'View Time Table' => '',
                );
            $data['rsTimetable'] = $this->timetable_model->getTimetable($bid,$semid);
            $data['rsBranch'] = $this->branch_model->getBranch();
            $data['rsSubject'] = $this->subject_model->getSubject($bid=$bid,$sid=null,$sno=$semid);
            $data['rsTeacher'] = $this->teacher_model->getTeacher();
            $data['rsRoom'] = $this->room_model->getRoom();
            $this->load->view('page_header',$data);
            $this->load->view('page_left_sildebar');
            $this->load->view("timetable/view-timetable");
            $this->load->view('page_footer');
    }
    public function getForm()
    {

       $semid    = $this->input->post('semid');
       $bid      = $this->input->post('bid');

       $rsTable   = $this->timetable_model->gettable($bid,$semid);
       $rsSubject = $this->subject_model->getSubject($bid=$bid,$sid=null,$sno=$semid);
       $rsTeacher = $this->teacher_model->getTeacher();
       $rsRoom    = $this->room_model->getRoom();

       $roomContaint ="<option value='' >Select any One</option>";
       $teacherContaint ="<option value='' >Select any One</option>";
       $subjectContaint ="<option value='' >Select any One</option>";

       foreach ($rsRoom as $value) {
           $roomContaint.= '<option value="'.$value['RNO'].'">'.$value['rname'].'</option>';
       }
        foreach ($rsSubject as $value) {
           $subjectContaint.= '<option value="'.$value['SUBID'].'">'.$value['subcode'].'('.$value['subname'].')</option>';
       }
        foreach ($rsTeacher as $value) {
           $teacherContaint.= '<option value="'.$value['USER_ID'].'">'.$value['user_name'].'</option>';
       }

       if(count($rsTable)==0)
        { ?>
            <style type="text/css">
                .selectboxa
                {
                    width: 90%;
                }
            </style>
            <?php

            $daysvalue = array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
            echo '
            <br/>
            <div class="row table-rsponsive">
                <table class="table table-border table-striped ">
                <thead>
                    <tr>
                        <th>D/T</th>
                        <th>10 to 11<input type="checkbox" class="checkSelect" name="first" data-id="2"/></th>
                        <th>11 to 12<input type="checkbox" class="checkSelect" name="second" data-id="3"/></th>  
                        <th>12 to 01<input type="checkbox" class="checkSelect" name="thired" data-id="4"/></th>
                        <th>01 to 02<input type="checkbox" class="checkSelect" name="fourth" data-id="5"/></th>
                        <th>02 to 03<input type="checkbox" class="checkSelect" name="fivth" data-id="6"/></th>
                        <th>03 to 04<input type="checkbox" class="checkSelect" name="sixth" data-id="7"/></th>
                        <th>04 to 05<input type="checkbox" class="checkSelect" name="seven" data-id="8"/></th>
                    </tr>
                </thead>
                <tbody>
               ';
               for ($i=0; $i <count($daysvalue) ; $i++) { 
                    echo '<tr>
                        <td>'.$daysvalue[$i].'<input type="hidden" name="days[]" value="'.$daysvalue[$i].'"></td>';
                        for ($j=0; $j< 7 ; $j++) { 
                           echo '<td>
                        <select name="subject'.$i.'[]" class="form-control form-control-sm selectboxa subjectid" >'.$subjectContaint.'</select>
                        <select name="room'.$i.'[]" class="form-control form-control-sm selectboxa roomid" onblur=getroom(this,"'.$daysvalue[$i].'",'.$j.')  >'.$roomContaint.'</select>
                        <select name="teacher'.$i.'[]" class="form-control form-control-sm selectboxa teacherid" onblur=getteacher(this,"'.$daysvalue[$i].'",'.$j.') >'.$teacherContaint.'</select></td>';
                        }
                    echo'</tr>';
               }
               echo '
                </tbody>
            </table>
            <center>
                    <button class="btn btn-success btn-md">Submit</button>
                    <button class="btn btn-md" type="reset">Reset</button>
            </center>
            </div>';
            ?>
            <script>
             $('.checkSelect').change(function(){
                if($(this).prop("checked")==true)
                 {
                     var id  = $(this).data('id');
                     var room  = $('table tbody tr:nth-child(1) td:nth-child('+id+') .roomid').children("option:selected").val();
                     var teacher  = $('table tbody tr:nth-child(1) td:nth-child('+id+') .teacherid').children("option:selected").val();
                     var subject  = $('table tbody tr:nth-child(1) td:nth-child('+id+') .subjectid').children("option:selected").val();
                     for(var i=2; i<=6; i++)
                     {
                        $('table tbody tr:nth-child('+i+') td:nth-child('+id+') .roomid').val(room);
                        $('table tbody tr:nth-child('+i+') td:nth-child('+id+') .teacherid').val(teacher);
                        $('table tbody tr:nth-child('+i+') td:nth-child('+id+') .subjectid').val(subject);
                     }
                 }
            });
             function getroom(a,daysname,columcount)
             {
                var id =$(a).val();
                if(id!='')
                    {
                    $.ajax({
                        url:'<?= site_url("room/checkroomable")?>',
                        data:{id:id,daysname:daysname,columcount:columcount},
                        method:'post',
                        dataType:'json',
                        success: function(json)
                        {   
                           if(json!='')
                           {
                            $('#myModal').modal();
                            $('#myModal .modal-title').html("Error");
                            $('#myModal .modal-body').html("This Room is already allocated for this time. <b>Please select another room</b>");
                            $('#myModal').on('hidden.bs.modal', function () {
                                    $(a).focus();
                                 });
                                
                           }
                       }              
                    })
                }
             }
              function getteacher(a,daysname,columcount)
             {
                    var id = $(a).val();
                    if(id!='')
                    {
                        $.ajax({
                            url:'<?= site_url("teacher/checkteacherable")?>',
                            data:{id:id,daysname:daysname,columcount:columcount},
                            method:'post',
                            dataType:'json',
                            success: function(json)
                            {   
                               if(json!='')
                               {
                                $('#myModal').modal();
                                $('#myModal .modal-title').html("Error");
                                $('#myModal .modal-body').html("This <b>Teacher</b> is already allocated for this time. <b>Please select another Teacher Name<b>");
                                $('#myModal').on('hidden.bs.modal', function () {
                                        $(a).focus();
                                 });
                               }
                           }              
                        })
                    }
             }
            </script>
            <?php
        }
        else
        {
            $msg = array('statusType'=>'warning','statusMsg'=>'This Branch record already exits.');
            $this->session->set_flashdata($msg);
            echo "1";//record already exits
        }

    }
    public function pdf_timetable($bid,$semid)
    {
        $data['rsTimetable'] = $this->timetable_model->getTimetable($bid,$semid);
        $data['rsBranch'] = $this->branch_model->getBranch();
        $data['rsSubject'] = $this->subject_model->getSubject($bid=$bid,$sid=null,$sno=$semid);
        $data['rsTeacher'] = $this->teacher_model->getTeacher();
        $data['rsRoom'] = $this->room_model->getRoom();
        $this->load->view("timetable/pdf-timetable",$data);
    }
    //form for current search
    public function current()
    {
        $data['title']="Time table";
        $data['breadcrumbs'] = array(
         'Home' => site_url('dashboard'),
         'Search' => '',
            );
        $data['rsTeacher'] = $this->teacher_model->getTeacher();
        $data['rsRoom']     = $this->room_model->getRoom();
        $this->load->view('page_header',$data);
        $this->load->view('page_left_sildebar');
        $this->load->view("timetable/current");
        $this->load->view('page_footer');
    }
    public function getsearchresult()
    {
        $result     = $this->timetable_model->getFitler();
        $rsTeacher  = $this->teacher_model->getTeacher();
        $rsRoom     = $this->room_model->getRoom();
        $period     = $this->input->post('period');
        $rsBranch   = $this->branch_model->getBranch();
       if(!empty($result))
       {
        $branchname= '';
        $roomname ='';
        $teachername= '';
        foreach ($rsBranch as  $value) {
            if($value['bid']==$result[0]['class'])
            {
                $branchname = $value['bname'];
            }
        }
        foreach ($rsRoom as  $value) {
            if($value['RNO']== $result[0]['slotroom'.$period])
            {
                $roomname = $value['rname'];
            }
        }
        foreach ($rsTeacher as  $value) {
            if($value['USER_ID'] == $result[0]['slotteacher'.$period])
            {
                $teachername =$value['user_name'];
            }
        }
         echo '<div class="form-Group"><label>Day:</label><input type="text" readonly value="'.$result[0]['days_name'].'" class="form-control"></div>';
         echo '<div class="form-Group"><label>Branch:</label><input type="text" readonly value="'.$branchname.'" class="form-control"></div>';
         echo '<div class="form-Group"><label>Semester</label><input type="text" readonly value="'.$result[0]['section'].'" class="form-control"></div>';
         echo '<div class="form-Group"><label>Room Name.</label><input type="text" readonly value="'.$roomname.'" class="form-control"></div>';
          echo '<div class="form-Group"><label>Teacher Name.</label><input type="text" readonly value="'.$teachername.'" class="form-control"></div>';
       }
       else
       {
        echo "No Record Found";
       }

    }
}// class LoginController

?>
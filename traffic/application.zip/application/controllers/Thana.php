<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Thana extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->isNotLoggedIn();
	    $this->load->helper(array('url','form','date'));
	    $this->load->database();
	  	$this->load->model('thana_model');
	  	$this->load->model('area_model');
	  	$this->load->model('station_model');
        $this->load->model('user_model');
        $this->load->model('profile_model');
	  	$this->load->library("form_validation");
	}
    //for the first page of teacher
	public function index()
	{
			$data['title']="Thana Incharge";
			$data['breadcrumbs'] = array(
			 'Home' => site_url('dashboard'),
			 'Thana Incharge' => '',
				);
			$data['rsThana'] =$this->thana_model->getThana();
	    	$this->load->view('page_header',$data);
			$this->load->view('page_left_sildebar');
			$this->load->view("thana/show-thana");
			$this->load->view('page_footer');
	} //end of view teacher
    //start of view timetable
	public function view_table($tid)
    {
        $data['rsTable'] = $this->timetable_model->gettable($bid=null,$semid=null,$roomid=null,$teacherid=$tid);
        $data['title']="Teacher";
        $data['breadcrumbs'] = array(
         'Home' => site_url('dashboard'),
         'Teacher' => site_url('teacher'),
         'View Table' => ''
            );
        $data['rsRoom']=$this->room_model->getRoom();
        $data['rsSubject'] = $this->subject_model->getSubject();
        $data['rsTeacher'] = $this->teacher_model->getTeacher();
        $data['teacherid'] = $tid;
        $this->load->view('page_header',$data);
        $this->load->view('page_left_sildebar');
        $this->load->view("teacher/view-teacher-table");
        $this->load->view('page_footer');
    }
    //teacher add form
    public function thana_form()
    {
    	$data['title']="Add Thana";
        $data['breadcrumbs'] = array(
         'Home' => site_url('dashboard'),
         'Thana' => site_url('thana'),
         'Add Thana' => ''
            );
        $this->load->view('page_header',$data);
        $this->load->view('page_left_sildebar');
        $this->load->view("thana/thana-form");
        $this->load->view('page_footer');
    }
    //end of teacher add form
    //process of teacher add
    public function add_thana()
    {
          $this->form_validation->set_rules('tname','Thana Incharge Name','required');
      		$this->form_validation->set_rules('temail','Thana Incharge Email','required|valid_email');
    		if($this->form_validation->run()==TRUE)
    		{
    			$tid = $this->thana_model->insert_thana();	//insert teacher
    			$new_name = "Thana_Incharge";
                $config['file_name']              = $new_name;
                $config['upload_path']            = 'assets/profile/user';
                $config['allowed_types']          = 'jpg|png|jpeg';
                $config['max_filename_increment'] = 1000;
                $this->load->library('upload', $config);
                if($this->upload->do_upload('timg'))//file upload
                {
                   $fileattr = array('upload_data' => $this->upload->data());
                   $fileName =   $config['upload_path'].'/'.$fileattr['upload_data']['file_name'];
                   $data =array(
                      'user_img'=>$fileName,
                    );
                   $this->thana_model->update_thana($data,$tid);
                }
                else
                {
                  $error = array('error' => $this->upload->display_errors());
                }
    			if($tid)
    			{
    				$msg = array('statusType'=>'success','statusMsg'=>'Record Inserted successfully.');
    	   		    $this->session->set_flashdata($msg);
    				$this->index();
    			}
    			else
    			{
    				$msg = array('statusType'=>'danger','statusMsg'=>'Some problam occurs record not inserted.');
    				$this->session->set_flashdata($msg);
    				$this->index();
    			}
    		}
    		else
    		{
    			$this->thana_form();
    		}
    }
    //end of teacher process 
    //start of teacher delete 
    public function delete_thana($userid)
    {
     $id =  $this->thana_model->del_thana($userid);
     $msg = array('statusType'=>'success','statusMsg'=>'Record Deleted Successfully.');
            $this->session->set_flashdata($msg);
            $this->index();
    }
    //end of teacher delete
    //this is show when teacher login and see his time table
    public function my_time_table()
    {
        $tid = $this->teacher_model->getTeacher($this->session->uid);
        $data['rsTable'] = $this->timetable_model->gettable($bid=null,$semid=null,$roomid=null,$teacherid=$tid['USER_ID']);
        $data['title']="My Time Table";
        $data['breadcrumbs'] = array(
         'Home' => site_url('dashboard'),
         'Table Table' => ''
            );
        $data['rsRoom'] = $this->room_model->getRoom();
        $data['rsSubject'] = $this->subject_model->getSubject();
        $data['rsTeacher'] = $this->teacher_model->getTeacher();
        $data['teacherid'] = $tid['USER_ID'];
        $this->load->view('page_header',$data);
        $this->load->view('page_left_sildebar');
        $this->load->view("teacher/view-my-table");
        $this->load->view('page_footer');
    }
    //end of teacher login time table
    //this is that teacher is avalible or not
    public function checkteacherable()
    {
        $this->form_validation->set_error_delimiters('<p class="alert alert-danger">', '</p>');
        $this->form_validation->set_rules('id','Teacher id','required');
        $this->form_validation->set_rules('daysname','Days Name','required');
        $this->form_validation->set_rules('columcount','Column Name','required');
        if($this->form_validation->run()==TRUE)
        {
            $teacherdetails = $this->teacher_model->check_teacher();
            echo json_encode($teacherdetails);
        }
        else
        {
            echo validation_errors();
        }   
    }
    //end of teacher avalible
    //check at the time of edit the time table
    public function checkteacherableedit()
    {
        $this->form_validation->set_error_delimiters('<p class="alert alert-danger">', '</p>');
        $this->form_validation->set_rules('id','Teacher id','required');
        $this->form_validation->set_rules('daysname','Days Name','required');
        $this->form_validation->set_rules('columcount','Column Name','required');
        $this->form_validation->set_rules('branchid','Branch Name','required');
        $this->form_validation->set_rules('semsterNo','Semester Name','required');
        if($this->form_validation->run()==TRUE)
        {
            $teachertails = $this->teacher_model->check_teacher();
            if($teachertails[0]['class']==$this->input->post("branchid") && $teachertails[0]['section']==$this->input->post("semsterNo"))
            {
                
            }
            else
            {
                echo json_encode($teachertails);    
            }
        }
        else
        {
            echo validation_errors();
        }    
    }
    //end of it
    //this is for the print of the time table
    public function pdf_teacher($tid)
    {
        $data['rsTable'] = $this->timetable_model->gettable($bid=null,$semid=null,$roomid=null,$teacherid=$tid);
  
        $data['rsRoom']=$this->room_model->getRoom();
        $data['rsSubject'] = $this->subject_model->getSubject();
        $data['rsTeacher'] = $this->teacher_model->getTeacher();
        $data['teacherid'] = $tid;
        $this->load->view("teacher/pdf-teacher",$data);
    }
    //end of time table pdf
    //edit the teacher
    public function edit_form($userid)
    {
        if($this->session->user_type==0)
        {
            $data['thana_detail'] = $this->thana_model->getThana($userid);   
        }
        else
        {
            $msg = array('statusType'=>'danger','statusMsg'=>'!You are not a authorized person.');
            $this->session->set_flashdata($msg);
            $this->index();
        }
        $data['title']="Edit Thana Incharge";
        $data['breadcrumbs'] = array(
         'Home' => site_url('dashboard'),
         'Thana Incharge' => site_url('thana'),
         'Edit Thana Incharge' => '',
            );
        $this->load->view('page_header',$data);
        $this->load->view('page_left_sildebar');
        $this->load->view("thana/thana-edit-form");
        $this->load->view('page_footer');
    }
    //end of edit teacher form
    //start of update the teacher
    public function edit_thana()
    {
        $this->form_validation->set_rules('tname','Thana Incharge Name','required');
        $this->form_validation->set_rules('temail','Thana Incharge Email','required|valid_email');
            if($this->form_validation->run()==TRUE)
            {
                $userid =  $this->input->post("userid");
                $data =array(
                      'user_name'    => $this->input->post("tname"),
                      'user_mobile'  => $this->input->post("tmobile"),
                      'user_email'   => $this->input->post("temail"),
                      'user_address' => $this->input->post("taddress"),
                      'user_city'    => $this->input->post("tcity"),
                      'user_state'   => $this->input->post("tstate"),
                    );
                $updateUser = $this->thana_model->update_thana($data,$userid);  
                $new_name = "Thana_Incharge";
                $config['file_name']              = $new_name;
                $config['upload_path']            = 'assets/profile/user';
                $config['allowed_types']          = 'jpg|png|jpeg';
                $config['max_filename_increment'] = 1000;
                $this->load->library('upload', $config);
                if($this->upload->do_upload('timg'))
                {
                   $fileattr = array('upload_data' => $this->upload->data());
                   $fileName =   $config['upload_path'].'/'.$fileattr['upload_data']['file_name'];
                   $data =array(
                      'user_img'=>$fileName,
                    );
                   $this->thana_model->update_thana($data,$userid);
                }
                else
                {
                  $error = array('error' => $this->upload->display_errors());
                }
                if($updateUser)
                {
                    $msg = array('statusType'=>'success','statusMsg'=>'Record Updated successfully.');
                     $this->session->set_flashdata($msg);
                    $this->index();
                }
                else
                {
                    $msg = array('statusType'=>'danger','statusMsg'=>'Some problam occurs record not inserted.');
                    $this->session->set_flashdata($msg);
                    $this->index();
                }
            }
            else
            {
                $this->edit_form($this->input->post("userid"));
            }
    }
    //end of update teacher
    //check emial id on teacher add
    public function check_email()
    {
        $emailid = $this->input->post("id");
        $res = $this->user_model->check_useremail($emailid);
        print_r($res);
        
    }
    //change the password of teacher
    public function change_password()   
    {
         $this->form_validation->set_rules('upassword', 'User Password', 'required');
         $this->form_validation->set_rules('confirmPassword', 'Confirm Password','required');
        if ($this->form_validation->run() == FALSE)
        {
            $data['error_message'] = validation_errors();
            echo json_encode($data);
        }
        else if($this->input->post('upassword')!=$this->input->post('confirmPassword'))
        {
           $data['error_message'] = "<p>New Password and Confirm Password should Same</p>";
              echo json_encode($data);
        }
        else
        {
            $data = array(
                    'user_pass'         => base64_encode(md5($this->input->post('upassword'))),
                    'operation'         => 'update',
                    'operation_date'    => date("Y-m-d H:i:s"),
                    'operation_userid'  => $this->session->uid,
                    );
              $this->profile_model->update_profile($data,$this->input->post('userid'));
              $msg = array('statusType'=>'success','statusMsg'=>' You Successfully Updated the Password');
             $this->session->set_flashdata($msg);
             echo '1';
        }
    }//end of the chage password
}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Subject extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->isNotLoggedIn();
	    $this->load->helper(array('url','form','date'));
	    $this->load->database();
	  	$this->load->model('branch_model');
	  	$this->load->model('subject_model');
	  	$this->load->model('user_model');
	  	$this->load->model("room_model");
	  	$this->load->model("teacher_model");
	  	$this->load->model("timetable_model");
	  	$this->load->library("form_validation");
	}
	public function index()
	{
			$data['title']="Subject";
			$data['breadcrumbs'] = array(
			 'Home' => site_url('dashboard'),
			 'Subject' => '',
				);
			$data['user'] = $this->user_model->user_detail($this->session->uid);
			$data['rsSubject'] =$this->subject_model->getSubject();
	    	$this->load->view('page_header',$data);
			$this->load->view('page_left_sildebar');
			$this->load->view("subject/show-subject");
			$this->load->view('page_footer');
	} //end of view class
	public function delete_subject($sno)
	{
	   $this->subject_model->delete_sub($sno);
       $msg = array('statusType'=>'success','statusMsg'=>'Record Deleted successfully.');
	   $this->session->set_flashdata($msg);
	   redirect('subject');
	}//delete_subject

	public function subject_form($bid=null)
	{
		$data['title']="Add Subject";
		$data['user'] = $this->user_model->user_detail($this->session->uid);
		$data['breadcrumbs'] = array(
			 'Home' => site_url('dashboard'),
			 'Subject' => site_url("subject"),
			 'Add Subject'=>'',
				);
		if($bid!=null)
			{
				$data['branchID']=$bid;
				$this->load->view('page_header',$data);
			}
		else
			{
				$data['rsbranch']=$this->branch_model->getBranch();
				$this->load->view('page_header',$data);
			}
			$this->load->view('page_left_sildebar');
			$this->load->view("subject/subject-form");
			$this->load->view('page_footer');
	}//this is for add the subject form
	public function add_subject()
	{
        $this->form_validation->set_rules('branchid','Branch Name','required');
		$this->form_validation->set_rules('semsterNo','Semester','required');
		$this->form_validation->set_rules('subCode[]','Subject Code','required');
		$this->form_validation->set_rules('subName[]','Subject Name','required');
		$this->form_validation->set_rules('subStatussub[]','Subject Status','required');
		if($this->form_validation->run()==TRUE)
		{
			$subid['subid'] =$this->subject_model->insert_subject();	
			if($subid)
			{
				$msg = array('statusType'=>'success','statusMsg'=>'Record Inserted successfully.');
	   			$this->session->set_flashdata($msg);
				$this->index();
			}
			else
			{
				$msg = array('statusType'=>'danger','statusMsg'=>'Some problam occurs record not inserted.');
				$this->session->set_flashdata($msg);
				$this->index();
			}
		}
		else
		{
			$this->subject_form();
		}
	}
	 public function get_subject_singlerow()
    {
        $sno = $this->input->post('sno');
        $data['rowSubject'] 	=   $this->subject_model->getSubject($bid=null,$sno);
        $data['rsbranch']  		= 	$this->branch_model->getBranch();
       
        echo json_encode(array(
        		"Subject"=>array(
        			"Name"		=>	$data['rowSubject']['sub_name'],
        			"branchid"	=>	$data['rowSubject']['sub_branchid'],
        			"semester"	=>	$data['rowSubject']['sub_semester'],
        			"status"	=>	$data['rowSubject']['sub_status'],
        		),
        		"Branch"=>$data['rsbranch'],
        	));
    }
    public function get_subject_record()
    {
    	 $data['rowSubject'] 	=   $this->subject_model->getSubject();

    	 echo  json_encode($data);
    }//for the ajax value idn question added form
     public function edit_subject_form($sno)
    {
       	$data['rowSubject']=$this->subject_model->getSubject($bid=null,$sid=$sno);
       	$data['title']="Edit Subject";
		$data['rsbranch']=$this->branch_model->getBranch();
		$data['breadcrumbs'] = array(
			 'Home' => base_url('dashboard'),
			 'Subject' => site_url("subject"),
			 'Edit Subject'=>'',
			);
       	$this->load->view('page_header',$data);
       	$this->load->view('page_left_sildebar');
		$this->load->view("subject/subject-edit");
		$this->load->view('page_footer');
    }
    public function edit_subject()
    {

    	$this->form_validation->set_rules('branchid','Branch Name','required');
		$this->form_validation->set_rules('semsterNo','Semester','required');
		$this->form_validation->set_rules('subCode','Subject Code','required');
		$this->form_validation->set_rules('subName','Subject Name','required');
		$this->form_validation->set_rules('subStatussub','Subject Status','required');
		$this->form_validation->set_rules('subjectid','Subject ID','required');
		if($this->form_validation->run()==TRUE)
		{
			$subid['subid'] =$this->subject_model->update_subject();	
			$msg = array('statusType'=>'success','statusMsg'=>'Record Updated successfully.');
   			$this->session->set_flashdata($msg);
			$this->index();
		}
		else
		{
			$this->edit_subject_form($this->input->post('subjectid'));
		}
    }
    public function view_table($subid)
    {
        $data['rsTable'] = $this->timetable_model->gettable($bid=null,$semid=null,$roomid=null,$teacherid=null,$subjectid=$subid);
        $data['title']="Subject";
        $data['breadcrumbs'] = array(
         'Home' => site_url('dashboard'),
         'Subject' => site_url('subject'),
         'View Table' => ''
            );
        $data['rsRoom']=$this->room_model->getRoom();
        $data['rsSubject'] = $this->subject_model->getSubject();
        $data['rsTeacher'] = $this->teacher_model->getTeacher();
        $data['subjectid'] = $subid;
        $this->load->view('page_header',$data);
        $this->load->view('page_left_sildebar');
        $this->load->view("subject/view-subject-table");
        $this->load->view('page_footer');
    }
    public function pdf_timetable($subid)
    {
    	 $data['rsTable'] = $this->timetable_model->gettable($bid=null,$semid=null,$roomid=null,$teacherid=null,$subjectid=$subid);
        $data['rsRoom']=$this->room_model->getRoom();
        $data['rsSubject'] = $this->subject_model->getSubject();
        $data['rsTeacher'] = $this->teacher_model->getTeacher();
        $data['subjectid'] = $subid;
        $this->load->view("subject/pdf-subject",$data);
    }

}
?>
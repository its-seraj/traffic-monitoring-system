<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Student extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->isNotLoggedIn();
	    $this->load->helper(array('url','form','date'));
	    $this->load->database();
	  	$this->load->model('branch_model');
	  	$this->load->model('teacher_model');
	  	$this->load->model('subject_model');
	  	$this->load->model('room_model');
        $this->load->model('user_model');
        $this->load->model('profile_model');
        $this->load->model('student_model');
	  	$this->load->model('timetable_model');
	  	$this->load->library("form_validation");
	}
    //for the first page of teacher
	public function index()
	{
			$data['title']="Student";
			$data['breadcrumbs'] = array(
			 'Home' => site_url('dashboard'),
			 'Student' => '',
				);
			$data['rsStudent'] =$this->student_model->getStudent();
	    	$this->load->view('page_header',$data);
			$this->load->view('page_left_sildebar');
			$this->load->view("Student/show-student");
			$this->load->view('page_footer');
	} //end of view student
	public function student_form()
    {
        $data['title']="Add Student";
        $data['breadcrumbs'] = array(
         'Home' => site_url('dashboard'),
         'Student' => site_url('student'),
         'Add Student' => ''
            );
        $data['rsBranch'] = $this->branch_model->getBranch();
        $this->load->view('page_header',$data);
        $this->load->view('page_left_sildebar');
        $this->load->view("student/student-form");
        $this->load->view('page_footer');
    }
    public function add_student()
    {
        $this->form_validation->set_rules('sname','Student Name','required');
        $this->form_validation->set_rules('semail','Student Email','required|valid_email');
        $this->form_validation->set_rules('branchid','Branch Name','required');
        $this->form_validation->set_rules('semesterNo','Semester ','required');
            if($this->form_validation->run()==TRUE)
            {
                $sid = $this->student_model->insert_student();  //insert teacher
                $new_name = "Student";
                $config['file_name']              = $new_name;
                $config['upload_path']            = 'assets/profile/user';
                $config['allowed_types']          = 'jpg|png|jpeg';
                $config['max_filename_increment'] = 1000;
                $this->load->library('upload', $config);
                if($this->upload->do_upload('simg'))//file upload
                {
                   $fileattr = array('upload_data' => $this->upload->data());
                   $fileName =   $config['upload_path'].'/'.$fileattr['upload_data']['file_name'];
                   $data =array(
                      'user_img'=>$fileName,
                    );
                   $this->student_model->update_student($data,$sid);
                }
                else
                {
                  $error = array('error' => $this->upload->display_errors());
                }
                if($sid)
                {
                    $msg = array('statusType'=>'success','statusMsg'=>'Record Inserted successfully.');
                    $this->session->set_flashdata($msg);
                    $this->index();
                }
                else
                {
                    $msg = array('statusType'=>'danger','statusMsg'=>'Some problam occurs record not inserted.');
                    $this->session->set_flashdata($msg);
                    $this->index();
                }
            }
            else
            {
                $this->student_form();
            }
    }
    //start delete student
    public function delete_student($userid)
    {
     $id =  $this->student_model->del_student($userid);
     $msg = array('statusType'=>'success','statusMsg'=>'Record Deleted Successfully.');
            $this->session->set_flashdata($msg);
            $this->index();
    }
    //edit form
     public function edit_form($userid)
    {
        if($this->session->user_type==0)
        {
            $data['student_detail'] = $this->student_model->getStudent($userid);   
        }
        else
        {
            $msg = array('statusType'=>'danger','statusMsg'=>'!You are not a authorized person.');
            $this->session->set_flashdata($msg);
            $this->index();
        }
        $data['rsBranch'] = $this->branch_model->getBranch();
        $data['title']="Edit Student";
        $data['breadcrumbs'] = array(
         'Home' => site_url('dashboard'),
         'Student' => site_url('student'),
         'Edit Student' => ''
            );
        $this->load->view('page_header',$data);
        $this->load->view('page_left_sildebar');
        $this->load->view("student/student-edit-form");
        $this->load->view('page_footer');
    }
    public function edit_student()
    {
        $this->form_validation->set_rules('sname','Student Name','required');
        $this->form_validation->set_rules('branchid','Branch Name','required');
        $this->form_validation->set_rules('semesterNo','Semester Name','required');
        $this->form_validation->set_rules('semail','Student Email','required|valid_email');

            if($this->form_validation->run()==TRUE)
            {
                $userid =  $this->input->post("userid");
                $data =array(
                      'user_name'    => $this->input->post("sname"),
                      'user_mobile'  => $this->input->post("smobile"),
                      'user_email'   => $this->input->post("semail"),
                      'user_address' => $this->input->post("saddress"),
                      'user_city'    => $this->input->post("scity"),
                      'user_state'   => $this->input->post("sstate"),
                    );
                $updateUser = $this->student_model->update_student($data,$userid);  
                $new_name = "Student";
                $config['file_name']              = $new_name;
                $config['upload_path']            = 'assets/profile/user';
                $config['allowed_types']          = 'jpg|png|jpeg';
                $config['max_filename_increment'] = 1000;
                $this->load->library('upload', $config);
                if($this->upload->do_upload('simg'))
                {
                   $fileattr = array('upload_data' => $this->upload->data());
                   $fileName =   $config['upload_path'].'/'.$fileattr['upload_data']['file_name'];
                   $data =array(
                      'user_img'=>$fileName,
                    );
                   $this->student_model->update_student($data,$userid);
                }
                else
                {
                  $error = array('error' => $this->upload->display_errors());
                }
                if($updateUser)
                {
                    $msg = array('statusType'=>'success','statusMsg'=>'Record Updated successfully.');
                     $this->session->set_flashdata($msg);
                    $this->index();
                }
                else
                {
                    $msg = array('statusType'=>'danger','statusMsg'=>'Some problam occurs record not inserted.');
                    $this->session->set_flashdata($msg);
                    $this->index();
                }
            }
            else
            {
                $this->edit_form($this->input->post("userid"));

            }
    }
    public function my_time_table()
    {

        $sid = $this->student_model->getStudent($this->session->uid);
            $data['title']="Time Table";
            $data['breadcrumbs'] = array(
             'Home' => site_url('dashboard'),
             'Time Table' => site_url('timetable'),
             'View Time Table' => '',
                );
            $data['rsTimetable'] = $this->timetable_model->getTimetable($sid['user_branch'],$sid['user_section']);
            $data['rsBranch'] = $this->branch_model->getBranch();
            $data['rsSubject'] = $this->subject_model->getSubject($bid=$sid['user_branch'],$sid=null,$sno=$sid['user_section']);
            $data['rsTeacher'] = $this->teacher_model->getTeacher();
            $data['rsRoom'] = $this->room_model->getRoom();
            $this->load->view('page_header',$data);
            $this->load->view('page_left_sildebar');
            $this->load->view("timetable/view-timetable");
            $this->load->view('page_footer');
        }
}
?>
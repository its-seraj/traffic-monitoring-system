<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Feedback extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->isNotLoggedIn();
	    $this->load->helper(array('url','form','date'));
	    $this->load->database();
	  	$this->load->model('branch_model');
	  	$this->load->model('user_model');
	  	$this->load->model("teacher_model");
	  	$this->load->model("student_model");
	  	$this->load->model("feedback_model");
	  	$this->load->library("form_validation");
	}
	public function index()
	{
			$data['title']="FeedBack";
			$data['breadcrumbs'] = array(
			 'Home' => site_url('dashboard'),
			 'Feedback' => '',
				);
			if($this->session->user_type!=0)
			{
				$data['rsFeedback'] =$this->feedback_model->getFeedback($this->session->uid);
			}
			else
			{
				$data['rsFeedback'] =$this->feedback_model->getFeedback();	
			}
			$data['rsTeacher'] = $this->teacher_model->getTeacher();
			$data['rsStudent'] = $this->student_model->getStudent();
	    	$this->load->view('page_header',$data);
			$this->load->view('page_left_sildebar');
			$this->load->view("feedback/show-feedback");
			$this->load->view('page_footer');
	} //end of view class
	 public function add_feedback()
    {
        $this->form_validation->set_error_delimiters('<p class="alert alert-danger">', '</p>');
        $this->form_validation->set_rules('teacherid','Teacher Name','required');
        $this->form_validation->set_rules('message','Meassage','required');
        if($this->form_validation->run()==TRUE)
        {
            $feedbackid = $this->feedback_model->insert_feedback();
            $msg = array('statusType'=>'success','statusMsg'=>'Feedback Successfully Inserted');
            $this->session->set_flashdata($msg); 
            echo "1";
        }
        else
        {
            echo validation_errors();
        }
    }
	 public function delete_feedback($fid)
    {

     $id =  $this->feedback_model->del_feedback($fid);
     $msg = array('statusType'=>'success','statusMsg'=>'Record Deleted Successfully.');
            $this->session->set_flashdata($msg);
            $this->index();
    }

}
?>
<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
Class Timetable_model extends CI_Model
{
  //get time table for all
  public function gettable($bid=null,$semid=null,$roomid=null,$teacherid=null,$subjectid=null)
  {
    if($bid!=null && $semid != null)
       {
        $query = $this->db->get_where('master',array('class'=>$bid,'  section'=>$semid, 'row_delete'=>0));
        return $query->row_array();
       }//all time table
       //if time table search by room number
    else if($roomid!=null)
       {	
       		$this->db->where_in("slotroom1" , $roomid);
          $this->db->or_where_in('slotroom2', $roomid);
          $this->db->or_where_in('slotroom3', $roomid);
          $this->db->or_where_in('slotroom4', $roomid);
          $this->db->or_where_in('slotroom5', $roomid);
          $this->db->or_where_in('slotroom6', $roomid);
          $this->db->or_where_in('slotroom7', $roomid);
       		$this->db->join('branch', 'branch.bid = master.class','left');
       		$this->db->order_by('MID');
      		$query = $this->db->get_where('master',array('master.row_delete'=>0));  
      		return $query->result_array();
       }
       //if timetable search by teacher
       else if($teacherid!=null)
       {

          $this->db->where_in("slotteacher1" , $teacherid);
          $this->db->or_where_in('slotteacher2', $teacherid);
          $this->db->or_where_in('slotteacher3', $teacherid);
          $this->db->or_where_in('slotteacher4', $teacherid);
          $this->db->or_where_in('slotteacher5', $teacherid);
          $this->db->or_where_in('slotteacher6', $teacherid);
          $this->db->or_where_in('slotteacher7', $teacherid);
          $this->db->join('branch', 'branch.bid = master.class','left');
          $this->db->order_by('MID');
          $query = $this->db->get_where('master',array('master.row_delete'=>0));
          return $query->result_array();
       }
       //if time table search by subject name
       else if($subjectid!=null)
       {
          $this->db->where_in("slotsub1" , $subjectid);
          $this->db->or_where_in('slotsub2', $subjectid);
          $this->db->or_where_in('slotsub3', $subjectid);
          $this->db->or_where_in('slotsub4', $subjectid);
          $this->db->or_where_in('slotsub5', $subjectid);
          $this->db->or_where_in('  slotsub6', $subjectid);
          $this->db->or_where_in('slotsub7', $subjectid); 
          $this->db->join('branch', 'branch.bid = master.class','left');
          $this->db->order_by('MID');
          $query = $this->db->get_where('master',array('master.row_delete'=>0));
          return $query->result_array();
       }
       else
       {
       	//this is for check error messages
       }
  }
  //get time table form by the branch and semester
  public function getTimetable($bid=null,$semid=null)
  {
  		if($bid!=null && $semid !=null)
  		{
	  		$this->db->join('branch','branch.bid = master.class');
	  		$this->db->order_by('MID');
		  	$query = $this->db->get_where('master',array('master.class'=>$bid,'master.section'=>$semid,'master.row_delete'=>0));
		  	return $query->result_array();
	  	}
  		else
  		{
  			$this->db->join('branch','branch.bid = master.class');
	  		$this->db->select('branch.bname,branch.bid,master.section,count(days_name) as daycount');
	  		$this->db->group_by(array("class", "section"));  // Produces: GROUP BY branch, Semester
	  		$query = $this->db->get_where('master',array('master.row_delete'=>0));
	  		return $query->result_array(); 	
  		}
  }
  //insert the time table to master
  public function insert_timetable()
  {

   $branchid    =  $this->input->post('branchid');
   $semid       =  $this->input->post('semsterNo');
   $days        =  $this->input->post("days[]");
   for ($i=0; $i <count($days); $i++) 
       {                        
             $data = array(
                "days_name" =>$days[$i],
                "class" => $branchid,
                "section" => $semid,
                "slotsub1" =>  $this->input->post("subject".$i."[]")[0],
                "slotroom1" => $this->input->post("room".$i."[]")[0],
                "slotteacher1" => $this->input->post("teacher".$i."[]")[0],

                "slotsub2" => $this->input->post("subject".$i."[]")[1],
                "slotroom2" => $this->input->post("room".$i."[]")[1],
                "slotteacher2" => $this->input->post("teacher".$i."[]")[1],

                "slotsub3" => $this->input->post("subject".$i."[]")[2],
                "slotroom3" => $this->input->post("room".$i."[]")[2],
                "slotteacher3" => $this->input->post("teacher".$i."[]")[2],

                "slotsub4" => $this->input->post("subject".$i."[]")[3],
                "slotroom4" => $this->input->post("room".$i."[]")[3],
                "slotteacher4" => $this->input->post("teacher".$i."[]")[3],

                "slotsub5" => $this->input->post("subject".$i."[]")[4],
                "slotroom5" => $this->input->post("room".$i."[]")[4],
                "slotteacher5" => $this->input->post("teacher".$i."[]")[4],

                "slotsub6" => $this->input->post("subject".$i."[]")[5],
                "slotroom6" => $this->input->post("room".$i."[]")[5],
                "slotteacher6" => $this->input->post("teacher".$i."[]")[5],

                "slotsub7" => $this->input->post("subject".$i."[]")[6],
                "slotroom7" => $this->input->post("room".$i."[]")[6],
                "slotteacher7" => $this->input->post("teacher".$i."[]")[6],
                "operation" => "insert",
                "operation_userid" => $this->session->uid,
                'operation_date'    =>  date("Y-m-d H:i:s"),
            );
         $this->db->insert('master',$data);
       }
  }
  //delete the timetable
  public function delete_time($bid,$sid)
  {
  		$data = array(
		    'row_delete' 		    => 1,
            'operation'    		  => 'Delete',
            'operation_userid'	=> $this->session->uid,
        );
		$this->db->where(array('class'=>$bid,'section'=>$sid));
		$this->db->update('master', $data);
  }
  //update time table
  public function update_timetable()
  {
   $branchid    =  $this->input->post('branchid');
   $semid       =  $this->input->post('semsterNo');
   $days        =  $this->input->post("days[]");
   $mid 		=  $this->input->post("mid[]");
   for ($i=0; $i <count($days); $i++) 
       {                        
             $data = array(
                "days_name" =>$days[$i],
                "class" => $branchid,
                "section" => $semid,

                "slotsub1" =>  $this->input->post("subject".$i."[]")[0],
                "slotroom1" => $this->input->post("room".$i."[]")[0],
                "slotteacher1" => $this->input->post("teacher".$i."[]")[0],

                "slotsub2" => $this->input->post("subject".$i."[]")[1],
                "slotroom2" => $this->input->post("room".$i."[]")[1],
                "slotteacher2" => $this->input->post("teacher".$i."[]")[1],

                "slotsub3" => $this->input->post("subject".$i."[]")[2],
                "slotroom3" => $this->input->post("room".$i."[]")[2],
                "slotteacher3" => $this->input->post("teacher".$i."[]")[2],

                "slotsub4" => $this->input->post("subject".$i."[]")[3],
                "slotroom4" => $this->input->post("room".$i."[]")[3],
                "slotteacher4" => $this->input->post("teacher".$i."[]")[3],

                "slotsub5" => $this->input->post("subject".$i."[]")[4],
                "slotroom5" => $this->input->post("room".$i."[]")[4],
                "slotteacher5" => $this->input->post("teacher".$i."[]")[4],

                "slotsub6" => $this->input->post("subject".$i."[]")[5],
                "slotroom6" => $this->input->post("room".$i."[]")[5],
                "slotteacher6" => $this->input->post("teacher".$i."[]")[5],

                "slotsub7" => $this->input->post("subject".$i."[]")[6],
                "slotroom7" => $this->input->post("room".$i."[]")[6],
                "slotteacher7" => $this->input->post("teacher".$i."[]")[6],
                "operation" => "update",
                "operation_userid" => $this->session->uid,
                'operation_date'    =>  date("Y-m-d H:i:s"),
            );
       	$this->db->where('MID', $mid[$i]);
        $this->db->update('master',$data);
       }
  }
  public function getFitler()
  {
    $teacher  =  $this->input->post('teacher');
    $room     =  $this->input->post('room');
    $period   =  $this->input->post('period');
    $date     =  $this->input->post('date');
    if($teacher !='')
      {
        $query =  $this->db->get_where('master',array("days_name"=>$date,"slotteacher".$period =>$teacher,'row_delete'=>0));
      }
    else
      {
        $query = $this->db->get_where('master',array("days_name"=>$date,"slotroom".$period =>$room,'row_delete'=>0));
      }
    return $query->result_array();
  }

}//class Timetable_model
?>
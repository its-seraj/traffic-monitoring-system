<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
Class Subject_model extends CI_Model
{
  //get the subject
  public function getSubject($bid=null,$sid=null,$sno=null,$status=null)
    {
      if($bid !=null && $sno!=null)
      {
         $this->db->join('branch','branch.bid = subject.bid');
         $query = $this->db->get_where('subject',array('subject.bid'=>$bid,'subject.semid'=>$sno,'subject.row_delete'=>0));
         return $query->result_array();
      }
    	else if($sid!=null)
    	{
        $this->db->join('branch','branch.bid = subject.bid');
    		$query = $this->db->get_where('subject',array('SUBID'=>$sid,'subject.row_delete'=>0));
        return $query->row_array();
    	}
    	else
    	{
        $this->db->join('branch','branch.bid = subject.bid');
    		$query = $this->db->get_where('subject',array('subject.row_delete'=>0));
        return $query->result_array();
    	}
    }
  //delete subject
  public function delete_sub($sno)
    {
    	$data = array(
  		        'row_delete' 		    => 1,
              'operation'    		  => 'Delete',
              'operation_userid'	=> $this->session->uid,
          );
  		$this->db->where('SUBID', $sno);
  		$this->db->update('subject', $data);
    }
  //insert new subject
  public function insert_subject()
    {
        $branchid    =   $this->input->post('branchid');
        $semsterNo   =   $this->input->post('semsterNo');
        $subCode     =   $this->input->post('subCode[]');
        $subName     =   $this->input->post('subName[]');
        $subStatus   =   $this->input->post('subStatussub[]');
        $subjectid = null;
       for ($i=0; $i<count($subName); $i++)
       {
        $data = array(
              'operation'        =>  'insert',
              'operation_userid' =>   $this->session->uid,
              'operation_date'   =>   date("Y-m-d H:i:s"),
              'subname'          =>   $subName[$i],
              'subcode'          =>   $subCode[$i],
              'bid'              =>   $branchid,
              'semid'            =>   $semsterNo,
              'substatus'        =>   $subStatus[$i],
          );
         $subjectid =  $this->db->insert('subject',$data);
       }
  	  return($subjectid);
    }
  //update subject
  public function update_subject()
    {
       $data = array(
              'operation'        =>  'update',
              'operation_userid' =>   $this->session->uid,
              'operation_date'   =>   date("Y-m-d H:i:s"),
              'subname'          =>   $this->input->post('subName'),
              'subcode'          =>   $this->input->post('subCode'),
              'bid'              =>   $this->input->post('branchid'),
              'semid'            =>   $this->input->post('semsterNo'),
              'substatus'        =>   $this->input->post('subStatussub'),
          );
       $this->db->where('SUBID', $this->input->post('subjectid'));
       $this->db->update('subject',$data);
    }
}//class subject model
?>
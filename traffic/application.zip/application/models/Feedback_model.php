<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
Class Feedback_model extends CI_Model
{
  public function getFeedback($userid=null)
    {
      if($userid!=null)
      {
         $query = $this->db->query("select * from feedback where tid='$userid' || sid= '$userid' && row_delete=0");
         return $query->result_array(); 
      }
      else
      {
        $query = $this->db->get_where('feedback',array('feedback.row_delete'=>0));
        return $query->result_array();  
      }
    }
      //=========insert feedback===========
  public function insert_feedback()
  {
      $data = array(
            'operation'       => 'insert',
            'operation_userid'=> $this->session->uid,
            'fmessage'        => $this->input->post('message'),
            'tid'             => $this->input->post('teacherid'),
            'sid'             => $this->session->uid,
            'operation_date'  => date("Y-m-d H:i:s"),
            'ftime'           => date("Y-m-d H:i:s"),
        );
      $this->db->insert('feedback',$data);
    return($this->db->insert_id());
  }
    public function del_feedback($fid)
    {
        $data =array(
                    'row_delete'=>1,
                    'operation'=>'Delete',
                    'operation_userid'=>$this->session->uid,
                    'operation_date' => date("Y-m-d H:i:s"),
                    );
        $this->db->where('fid', $fid);
        $feedback_deleted = $this->db->update('feedback', $data);
    }
}//class Teacher Modal
?>
<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Room_model extends CI_Model 
{
	public function __construct()
		{
		   parent::__construct();
		   $this->load->database();
		}//fun construct
	public function getRoom()
		{
			$this->db->order_by('RNO');
		 	$query =$this->db->get_where('room',array('room.row_delete'=>0));
			return $query->result_array();	
		}//fun select room
		//delete room 
	public function delete_rom($rno)
		 {
		  	$data = array(
				    'row_delete' 		    => 1,
		            'operation'    		    => 'Delete',
		            'operation_date'  		=>   date("Y-m-d H:i:s"),
		            'operation_userid'		=> $this->session->uid,
		        );
				$this->db->where('RNO', $rno);
				$this->db->update('room', $data);
		}
		//insert room
	public  function insert_room()
		{
			$roomName 	= $this->input->post('room_name');
			$roomStatus = $this->input->post('room_status');
			$roomType 	= $this->input->post('room_type');
			$roomFloor  = $this->input->post('room_floor');
			
			for ($i=0; $i <count($roomName); $i++) { 
				$data = array(
		            'operation'        =>  'insert',
		            'operation_userid' =>   $this->session->uid,
		            'operation_date'   =>   date("Y-m-d H:i:s"),
		            'rname'			   =>   $roomName[$i],
		            'status'		   =>   $roomStatus[$i],  
		            'rtype'			   =>   $roomType[$i],
		            'rfloor'		   =>   $roomFloor[$i],  
		        );
		     	 $roomid =  $this->db->insert('room',$data);
			}
		}
		//update room
	public function update_room()
		{
				$data = array(
		            'operation'        =>  'Update',
		            'operation_userid' =>   $this->session->uid,
		            'operation_date'   =>   date("Y-m-d H:i:s"),
		            'rname'			   => $this->input->post('room_name'),
		            'status'		   => $this->input->post('room_status'),
		            'rtype'			   => $this->input->post('room_type'),
		            'rfloor'		   => $this->input->post('room_floor'),  
		        );
			$this->db->where(array('RNO'=> $this->input->post('rno')));
	     	$roomid =  $this->db->update('room',$data);
		}
		//check room is valable or not
	public function check_room()
		{
			$id 		=	$this->input->post("id");
			$daysname 	=	$this->input->post("daysname");
			$columcount =	$this->input->post("columcount");
		    $columcount =	$columcount+1;
			$query =$this->db->get_where('master',array("days_name" => $this->input->post("daysname"),"slotroom".$columcount."" => $this->input->post("id")));
			return $query->result_array();	
		}

}//class User_model

?>
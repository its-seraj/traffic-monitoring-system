<?php
Class Branch_model extends CI_Model
{
  //============Get branch=========
  public function getBranch($bid=null,$status=null)
  {
  	if($bid!=null)
  	{
  		$query = $this->db->get_where('branch',array('bid'=>$bid,'row_delete'=>0));
      	return $query->row_array();
  	}
  	else
  	{
  		$query = $this->db->get_where('branch',array('row_delete'=>0));
       return $query->result_array();
  	}
  }
  //---------end of get branch-----

  //=========insert branch===========
  public function insert_branch()
  {
      $data = array(
            'operation'       => 'insert',
            'operation_userid'  => $this->session->uid,
            'bname'       => $this->input->post('branch_name'),
            'bstatus'     => $this->input->post('branch_status'),
            'semster_no'    => $this->input->post('semster_no'),
            'operation_date'    =>  date("Y-m-d H:i:s"),
        );
      $this->db->insert('branch',$data);
    return($this->db->insert_id());
  }
  //----------end of insert branch----

  //=========delete branch========
  public function delete_branch($bid)
  {
  		$data = array(
		        'row_delete' 		=> 1,
            'operation'    		=> 'Deleted',
            'operation_userid'	=> $this->session->uid,
            'operation_date'    =>  date("Y-m-d H:i:s"),
        );
		$this->db->where('bid', $bid);
		$this->db->update('branch', $data);
  }
  //----------end of delete branch----
  //=========update branch========
  public function update_branch()
  {
        $data = array(
            'operation'    		=> 'update',
            'operation_userid'	=> $this->session->uid,
            'bname'				=> $this->input->post('branch_name'),
            'bstatus'			=> $this->input->post('branch_status'),
            'semster_no'		=> $this->input->post('semster_no'),
            'operation_date'    =>  date("Y-m-d H:i:s"),
        );
        $this->db->where('bid',  $this->input->post('branch_id'));
		$this->db->update('branch', $data);
  }
  //-------end of the update branch------
 

}//class User_model
?>
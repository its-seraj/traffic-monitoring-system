<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
Class Student_model extends CI_Model
{
  //this is for get the teacher details
  public function getStudent($userid=null)
    {
      if($userid!=null)
      {
         $this->db->join('branch','branch.bid=user.user_branch','left');
         $query = $this->db->get_where('user',array('user.row_delete'=>0,'user.USER_ID'=>$userid));
         return $query->row_array(); 
      }
      else
      {
        $this->db->join('branch','branch.bid=user.user_branch','left');
        $query = $this->db->get_where('user',array('user.row_delete'=>0, 'user_role' => 3));
        return $query->result_array();  
      }
    }
  public function insert_student()
  {
      $data = array(
            'operation'        =>  'insert',
            'operation_userid' =>   $this->session->uid,
            'operation_date'   =>   date("Y-m-d H:i:s"),
            'user_role'        =>   3,
            'user_name'        =>   $this->input->post('sname'),
            'user_branch'      =>   $this->input->post('branchid'),
            'user_section'     =>   $this->input->post('semesterNo'),
            'user_email'       =>   $this->input->post('semail'),
            'user_mobile'      =>   $this->input->post('smobile'),
            'user_address'     =>   $this->input->post('saddress'),
            'user_city'        =>   $this->input->post('scity'),
            'user_state'       =>   $this->input->post('sstate'),
            'user_pass'        =>   base64_encode(md5($this->input->post('semail'))),
            'user_status'      =>   1,
          );
         $tid =  $this->db->insert('user',$data);
         $insertId = $this->db->insert_id();
         return $insertId;
  }
    public function update_student($data,$id)
    {
        $this->db->where('USER_ID', $id);
        $data = $this->db->update('user', $data);
        return($data);
    }
    public function del_student($userid)
    {
        $data =array(
                    'row_delete'=>1,
                    'operation'=>'Delete',
                    'operation_userid'=>$this->session->uid,
                    'operation_date' => date("Y-m-d H:i:s"),
                    );
        $this->db->where('USER_ID', $userid);
        $teacher_deleted = $this->db->update('user', $data);
    }
}//class Teacher Modal
?>
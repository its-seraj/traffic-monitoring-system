<?php
class Issue2145Test extends PHPUnit_Framework_TestCase
{
    public static function setUpBeforeClass()
    {
        throw new Exception;
    }

    public function testOne()
    {
    }

    public function testTwo()
    {
    }
}
